import sys,json,itertools,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy,add_path
from analyze_139_escape_blockers import protected_power
from escape_mesh import mesh_route,add_mesh_path
from shapely.geometry import box
base=Path('/workspace/scratch/d094b9146fd7/work139/eeg128-tdm.kicad_pcb');b=pcbnew.LoadBoard(str(base));power=protected_power(b)
main='CH021_N_ELECTRODE';src='CH027_P_ELECTRODE';tgt='CH023_N_ELECTRODE'
kept27={(38.75,21.779999),(36.55,6.279999),(36.55,10.379999)}
removed=[]
for t in b.GetTracks():
 if t.GetNetname()==src:
  a,c=xy(t.GetStart()),xy(t.GetEnd())
  if isinstance(t,pcbnew.PCB_VIA):remove=a not in kept27
  elif t.GetLayer()==pcbnew.B_Cu:remove=a!=(36.55,6.279999)
  else:remove=not ((a[0]>=38.75 and c[0]>=38.75 and a[1]>=20.7 and c[1]>=20.7) or max(a[1],c[1])<10.38)
  if remove:removed.append(t)
 if t.GetNetname()==tgt:
  a,c=xy(t.GetStart()),xy(t.GetEnd())
  if isinstance(t,pcbnew.PCB_VIA):remove=a!=(36.55,11.979999)
  elif t.GetLayer()==pcbnew.In2_Cu:remove=True
  else:remove=min(a[0],c[0])>40
  if remove:removed.append(t)
for t in removed:b.Remove(t)
print('removed',len(removed),flush=True)

from route_targeted_closure import make_via
case=int(sys.argv[1]);via=[(50.4762,8.808369),(50.5,10.5),(49.2,9.8),(51.5,7.8)][case%4]
paths=[]
requests=[(tgt,(44.25,7.6),via,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False),
          (tgt,(36.55,11.979999),via,(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True),
          (src,(36.55,10.379999),(38.75,21.779999),(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True),
          (main,(43.25,7.6),(36.15,18.2),(pcbnew.F_Cu,pcbnew.In2_Cu),0,0,True)]
if case>=4:requests[1],requests[2]=requests[2],requests[1]
for i,(name,start,goal,layers,sl,gl,allow) in enumerate(requests):
 net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==name)
 path=mesh_route(b,start,goal,net,layers,power,box(25,.5,57,35.9),start_layer=sl,goal_layer=gl,allow_vias=allow)
 print(i,name,path is not None,flush=True)
 paths.append({'net':name,'layers':[b.GetLayerName(l) for l in layers],'path':path})
 if path is None:break
 add_mesh_path(b,path,net,layers)
 if i==0:make_via(b,via,net,.6)
out=Path('/workspace/scratch/d094b9146fd7/round2')/f'dogleg-case{case}';out.mkdir(exist_ok=True)
event={'case':case,'via':via,'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'complete':len(paths)==4 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False}
(out/'plan.json').write_text(json.dumps(event,indent=2))
if event['complete']:
 target=out/base.name;pcbnew.SaveBoard(str(target),b)
 for ext in ('.kicad_pro','.kicad_dru'):shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
 print('COMPLETE',out,flush=True)
