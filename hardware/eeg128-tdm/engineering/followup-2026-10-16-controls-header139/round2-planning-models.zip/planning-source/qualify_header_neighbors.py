import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import native_fresh,metrics,make_via
from escape_mesh import add_mesh_path
from analyze_139_escape_blockers import protected_power,windows
from native_connectivity import regressed_nets
from audit_block1_corridor_geometry import power_copper,outlines
from shapely.geometry import box
root=Path('/workspace/scratch/d094b9146fd7/round2');data=json.loads((root/'local27-fb-case1/plan.json').read_text());base=Path('/workspace/scratch/d094b9146fd7/work139/eeg128-tdm.kicad_pcb');out=root/'header-neighbors-native';out.mkdir(exist_ok=True);target=out/base.name
b=pcbnew.LoadBoard(str(base));removed=[t for t in b.GetTracks() if t.m_Uuid.AsString() in data['removed']]
for t in removed:b.Remove(t)
for i,r in enumerate(data['paths']):
 if not r['path']:break
 net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==r['net'])
 layers=tuple(b.GetLayerID(l) for l in r['layers']);add_mesh_path(b,r['path'],net,layers)
 if i in (0,2):make_via(b,data['via27' if i==0 else 'via23'],net,.6)
pcbnew.SaveBoard(str(target),b)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
after=native_fresh(target,out/'drc.json')
before=json.loads(Path('/workspace/scratch/d094b9146fd7/replay139/drc-after.json').read_text());a,b=pcbnew.LoadBoard(str(base)),pcbnew.LoadBoard(str(target));p0,p1=power_copper(a),power_copper(b)
net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()=='CH021_N_ELECTRODE');comp,w=windows(b,net,(43.25,7.6),box(25,.5,57,35.9),protected_power(b));_,sw=windows(b,net,(36.15,18.2),box(25,.5,57,35.9),protected_power(b))
r={**metrics(after),'regressed_nets':regressed_nets(before,after),'L3_power_loss_mm2':p0.difference(p1).area,'L3_power_gain_mm2':p1.difference(p0).area,'zone_outlines_unchanged':outlines(a)==outlines(b),'E21_target_window':w,'E21_source_window':sw,'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'result.json').write_text(json.dumps(r,indent=2));print(r)
