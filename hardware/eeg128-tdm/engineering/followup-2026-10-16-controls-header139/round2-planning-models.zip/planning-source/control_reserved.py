import sys,json,shutil,itertools
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy,make_via,obstacles
from analyze_139_escape_blockers import protected_power,windows
from escape_mesh import mesh_route,add_mesh_path
from shapely.geometry import box,Point
root=Path('/workspace/scratch/d094b9146fd7/round2');case=int(sys.argv[1]);base=Path('/workspace/scratch/d094b9146fd7/s1-replay/eeg128-tdm.kicad_pcb');b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(12,20,59,69)
ids=json.loads((root/'control-removals.json').read_text())['ids'];allowed={u for us in ids.values() for u in us};removed=[t for t in b.GetTracks() if t.m_Uuid.AsString() in allowed]
for t in removed:b.Remove(t)
paths=[];heads={'S3':(47.1875,33.628979),'ENroot':(28.4875,34.7),'ENtarget':(40.948552,33.348908)}
requests=[('MUX_S2',(45.0207,39.3061),(46.215,35.85),(pcbnew.F_Cu,pcbnew.B_Cu),0,0,True,None),
          ('MUX_S3',(47.485,35.85),heads['S3'],(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,heads['S3']),
          ('MUX_EN',(44.945,35.85),heads['ENtarget'],(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,heads['ENtarget']),
          ('MUX_EN',(24.8847,34.2644),heads['ENroot'],(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,heads['ENroot'])]
trunks=[('MUX_S1',(22.515,43.55),(46.115,43.55),(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True,None),
        ('MUX_S3',(26.4572,37.8222),heads['S3'],(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True,None),
        ('MUX_EN',heads['ENroot'],heads['ENtarget'],(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True,None)]
order=list(itertools.permutations(range(3)))[case]
requests += [trunks[i] for i in order]
requests += [('CH018_P_MUX',(32.75,26),(41.135,45.15),(pcbnew.F_Cu,pcbnew.B_Cu),0,0,True,None)]
for i,(name,start,goal,layers,sl,gl,allow,via) in enumerate(requests):
 net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==name)
 if via:
  _,obs=obstacles(b,net,.15,.15,region,.6,layers)
  if obs.covers(Point(via)) or power.buffer(.505).covers(Point(via)):
   print('blocked reserved via',name,via,flush=True);paths.append({'net':name,'path':None,'reason':'reserved via blocked'});break
 path=mesh_route(b,start,goal,net,layers,power,region,start_layer=sl,goal_layer=gl,allow_vias=allow)
 print(i,name,path is not None,flush=True);paths.append({'net':name,'layers':[b.GetLayerName(l) for l in layers],'path':path})
 if path is None:break
 add_mesh_path(b,path,net,layers)
 if via:make_via(b,via,net,.60)
result={'case':case,'removed':[t.m_Uuid.AsString() for t in removed],'heads':heads,'order':order,'paths':paths,'complete':len(paths)==8 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False}
out=root/f'control-reserved{case}';out.mkdir(exist_ok=True);(out/'plan.json').write_text(json.dumps(result,indent=2))
if result['complete']:
 target=out/base.name;pcbnew.SaveBoard(str(target),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
 print('COMPLETE',flush=True)
