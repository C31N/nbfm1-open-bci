import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import make_via,obstacles,native_fresh,metrics
from analyze_139_escape_blockers import protected_power,windows
from escape_mesh import mesh_route,add_mesh_path
from shapely.geometry import box,Point
root=Path('/workspace/scratch/d094b9146fd7/round2');base=root/'controls-native/eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(12,12,59,69);case=int(sys.argv[1]);net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()=='CH018_P_MUX')
_,sw=windows(b,net,(32.75,26),region,power);print('source windows',sw,flush=True)
sv=[(32.2625,35.646231),(32.930481,29.903291),(31.5525,27.275981),(33.003947,22.037563)][case];tv=(46.841954,34.399999)
requests=[((32.75,26),sv,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,sv),((41.135,45.15),tv,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,tv),(sv,tv,(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True,None)];paths=[]
for i,(start,goal,layers,sl,gl,allow,via) in enumerate(requests):
 if via:
  _,obs=obstacles(b,net,.15,.15,region,.6,layers)
  if obs.covers(Point(via)) or power.buffer(.505).covers(Point(via)):
   print('via blocked',via,flush=True);paths.append({'path':None,'reason':'via blocked'});break
 path=mesh_route(b,start,goal,net,layers,power,region,start_layer=sl,goal_layer=gl,allow_vias=allow)
 print(i,path is not None,flush=True);paths.append({'net':'CH018_P_MUX','layers':[b.GetLayerName(l) for l in layers],'path':path})
 if not path:break
 add_mesh_path(b,path,net,layers)
 if via:make_via(b,via,net,.6)
out=root/f'p-fixed{case}';out.mkdir(exist_ok=True);r={'case':case,'source_via':sv,'target_via':tv,'paths':paths,'complete':len(paths)==3 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 target=out/base.name;pcbnew.SaveBoard(str(target),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
 d=native_fresh(target,out/'drc.json');print('NATIVE',metrics(d),flush=True)
