import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import native_fresh,metrics
from audit_block1_corridor_geometry import power_copper
from native_connectivity import regressed_nets
root=Path('/workspace/scratch/d094b9146fd7/round2');base=root/'header-neighbors-native/eeg128-tdm.kicad_pcb';out=root/'header-clean';out.mkdir(exist_ok=True);target=out/base.name;b=pcbnew.LoadBoard(str(base));report=json.loads((root/'header-neighbors-native/drc.json').read_text());ids={i['uuid'] for v in report['violations'] if v['type']=='via_dangling' for i in v['items']}
removed=[t for t in b.GetTracks() if t.m_Uuid.AsString() in ids]
assert len(removed)==1 and all(isinstance(t,pcbnew.PCB_VIA) and t.GetNetname()=='CH027_P_ELECTRODE' for t in removed)
for t in removed:b.Remove(t)
pcbnew.SaveBoard(str(target),b)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
after=native_fresh(target,out/'drc.json');before=json.loads(Path('/workspace/scratch/d094b9146fd7/replay139/drc-after.json').read_text());a=pcbnew.LoadBoard('/workspace/scratch/d094b9146fd7/work139/eeg128-tdm.kicad_pcb');b=pcbnew.LoadBoard(str(target));p0,p1=power_copper(a),power_copper(b)
r={**metrics(after),'regressed_nets':regressed_nets(before,after),'L3_power_loss_mm2':p0.difference(p1).area,'L3_power_gain_mm2':p1.difference(p0).area,'removed_redundant_proposed_vias':sorted(ids),'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'result.json').write_text(json.dumps(r,indent=2));print(r)
