import sys,json,itertools,shutil,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy
from analyze_139_escape_blockers import protected_power,windows
from escape_mesh import mesh_route,add_mesh_path
from shapely.geometry import box
root=Path('/workspace/scratch/d094b9146fd7/round2');case=int(sys.argv[1]);base=Path('/workspace/scratch/d094b9146fd7/s1-replay/eeg128-tdm.kicad_pcb');b=pcbnew.LoadBoard(str(base));power=protected_power(b)
ids=json.loads((root/'control-removals.json').read_text())['ids'];allowed={u for us in ids.values() for u in us}
removed=[t for t in b.GetTracks() if t.m_Uuid.AsString() in allowed]
for t in removed:b.Remove(t)
orders=[['MUX_S1','MUX_S3','MUX_EN','MUX_S2','CH018_P_MUX'],['CH018_P_MUX','MUX_S1','MUX_S3','MUX_EN','MUX_S2'],['MUX_EN','MUX_S3','MUX_S2','MUX_S1','CH018_P_MUX'],['MUX_S3','MUX_S2','MUX_EN','MUX_S1','CH018_P_MUX'],['CH018_P_MUX','MUX_EN','MUX_S3','MUX_S2','MUX_S1'],['MUX_S1','MUX_EN','MUX_S2','MUX_S3','CH018_P_MUX']]
orders += [['MUX_S2','MUX_S3','MUX_EN','MUX_S1','CH018_P_MUX'],['MUX_S2','MUX_EN','MUX_S3','MUX_S1','CH018_P_MUX'],['MUX_S2','MUX_S1','MUX_S3','MUX_EN','CH018_P_MUX']]
order=orders[case];paths=[]
for name in order:
 net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==name)
 if name=='CH018_P_MUX':start,goal=(32.75,26),(41.135,45.15);layers=(pcbnew.F_Cu,pcbnew.B_Cu);sl=gl=0
 elif name=='MUX_S1':start,goal=(22.515,43.55),(46.115,43.55);layers=(pcbnew.B_Cu,pcbnew.In2_Cu);sl=gl=0
 elif name=='MUX_S2':start,goal=(45.0207,39.3061),(46.215,35.85);layers=(pcbnew.F_Cu,pcbnew.B_Cu);sl=gl=0
 elif name=='MUX_S3':start,goal=(26.4572,37.8222),(47.485,35.85);layers=(pcbnew.B_Cu,pcbnew.F_Cu);sl=0;gl=1
 else:start,goal=(24.8847,34.2644),(44.945,35.85);layers=(pcbnew.F_Cu,pcbnew.In2_Cu);sl=gl=0
 path=mesh_route(b,start,goal,net,layers,power,box(12,20,59,69),start_layer=sl,goal_layer=gl)
 print(name,'found',path is not None,flush=True);paths.append({'net':name,'layers':[b.GetLayerName(l) for l in layers],'path':path})
 if path is None:break
 add_mesh_path(b,path,net,layers)
result={'baseline':str(base),'baseline_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'case':case,'order':order,'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'complete':len(paths)==5 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False}
out=root/f'control-case{case}';out.mkdir(exist_ok=True);(out/'plan.json').write_text(json.dumps(result,indent=2))
if result['complete']:
 target=out/base.name;pcbnew.SaveBoard(str(target),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
 print('COMPLETE',flush=True)
