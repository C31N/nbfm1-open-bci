import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from replay_escape139_probes import recipe,apply
from route_targeted_closure import xy,make_via,obstacles,native_fresh,metrics
from analyze_139_escape_blockers import protected_power,windows
from escape_mesh import mesh_route,add_mesh_path
from shapely.geometry import box,Point
root=Path('/workspace/scratch/d094b9146fd7/round2');case=int(sys.argv[1]);out=root/f'c22-dogleg{case}';out.mkdir(exist_ok=True);base=Path('/workspace/scratch/d094b9146fd7/work139/eeg128-tdm.kicad_pcb');target=out/base.name
for ext in ['.kicad_pcb','.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
apply(target,recipe(),'c22');b=pcbnew.LoadBoard(str(target));power=protected_power(b);region=box(25,.5,57,35.9);main='CH021_N_ELECTRODE';tgt='CH023_N_ELECTRODE';removed=[]
for t in b.GetTracks():
 if t.GetNetname()!=tgt:continue
 x,y=xy(t.GetStart()),xy(t.GetEnd())
 remove=(x!=(36.55,11.979999)) if isinstance(t,pcbnew.PCB_VIA) else (True if t.GetLayer()==pcbnew.In2_Cu else min(x[0],y[0])>40)
 if remove:removed.append(t)
for t in removed:b.Remove(t)
net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==main);_,w=windows(b,net,(36.15,18.2),region,power);print('source area',w['legal_via_area_mm2'],flush=True)
if not w['windows']:
 (out/'plan.json').write_text(json.dumps({'complete':False,'accepted':False,'source_window':w}));target.unlink();sys.exit()
sv=tuple(round(v,6) for v in w['windows'][0]['point']);v23=(50.4762,8.808369);tv=(52.707002,7.486252)
requests=[(main,(36.15,18.2),sv,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,sv),
          (tgt,(44.25,7.6),v23,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,v23),
          (main,(43.25,7.6),tv,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,tv),
          (tgt,(36.55,11.979999),v23,(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True,None),
          (main,sv,tv,(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True,None)]
if case==1:requests[3],requests[4]=requests[4],requests[3]
paths=[]
for i,(name,start,goal,layers,sl,gl,allow,via) in enumerate(requests):
 net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==name)
 if via:
  _,obs=obstacles(b,net,.15,.15,region,.6,layers)
  if obs.covers(Point(via)) or power.buffer(.505).covers(Point(via)):
   print('via blocked',name,via,flush=True);paths.append({'net':name,'path':None,'reason':'via blocked'});break
 path=mesh_route(b,start,goal,net,layers,power,region,start_layer=sl,goal_layer=gl,allow_vias=allow)
 print(i,name,path is not None,flush=True);paths.append({'net':name,'layers':[b.GetLayerName(l) for l in layers],'path':path})
 if not path:break
 add_mesh_path(b,path,net,layers)
 if via:make_via(b,via,net,.6)
r={'case':case,'source_window':w,'source_via':sv,'target_via':tv,'via23':v23,'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'complete':len(paths)==5 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 pcbnew.SaveBoard(str(target),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
 d=native_fresh(target,out/'drc.json');print('NATIVE',metrics(d),flush=True)
else:target.unlink()
