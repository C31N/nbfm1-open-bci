import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy,native_fresh,metrics
from analyze_139_escape_blockers import protected_power
from escape_mesh import mesh_route,add_mesh_path
from native_connectivity import regressed_nets
from shapely.geometry import box
root=Path('/workspace/scratch/d094b9146fd7/round2');base=root/'controls-native/eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));power=protected_power(b);layers=(pcbnew.F_Cu,pcbnew.In2_Cu);net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()=='CH018_P_MUX')
path=mesh_route(b,(32.75,26),(41.135,45.15),net,layers,power,box(12,14,59,65));print('P found',path is not None,flush=True)
out=root/'p-close-in2';out.mkdir(exist_ok=True);(out/'plan.json').write_text(json.dumps({'net':'CH018_P_MUX','layers':['F.Cu','In2.Cu'],'path':path,'accepted':False,'routing_completed':False,'fabrication_release':False},indent=2))
if path:
 add_mesh_path(b,path,net,layers);target=out/base.name;pcbnew.SaveBoard(str(target),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
 after=native_fresh(target,out/'drc.json');print(metrics(after),flush=True)
