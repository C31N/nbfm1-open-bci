import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from analyze_139_escape_blockers import protected_power,windows
from route_targeted_closure import xy
from shapely.geometry import box
b=pcbnew.LoadBoard('/workspace/scratch/d094b9146fd7/s1-replay/eeg128-tdm.kicad_pcb')
ids={'MUX_S1':{'138f419d-0a9d-40a4-b2e0-55f057e31af2','34c8ec41-d8bb-4af4-9a4c-0b6f3a3f42ef','4879a0f1-312a-48c6-a543-bd36e574ab99','f2199d3b-40cd-4883-bf59-e3bb4fee43ec'},'MUX_S2':{'b8a7e577-b7a3-4b13-8884-67860f3a9e37','4497c433-0170-42fa-8f64-6ddc69e9f86e','35cccd8c-93aa-4c1c-9159-e9e77a7b2e10','ce16cff7-06c2-4423-95f5-483f9cf4edec','d63cd5b4-9b79-4d97-8e66-1895bb81d615','88a6d85e-5bcf-49cd-a045-f5a808dcdd67','8f2737c1-d414-4d82-b685-4ffa54394d93'},'MUX_S3':{'c320c092-5407-4ad6-9a97-2c324373271c','5086ca27-2c22-448d-a5e4-22e598d226d3','6e05d970-8374-436b-8798-2cd2f12a3bba'},'MUX_EN':{'c60a9727-6fd1-454e-b741-385c709863b3','721c2834-e08b-4b5f-a60d-4160225495c2','cd9d9336-51f4-4360-88ec-e43baf27e7f4','0de93751-3836-44ab-b8a8-aa295d30d510'}}
removed=[t for t in b.GetTracks() if t.m_Uuid.AsString() in set.union(*ids.values())]
for t in removed:b.Remove(t)
power=protected_power(b);result={}
for name,pt in [('CH018_P_MUX',(41.135,45.15)),('MUX_S3',(47.485,35.85)),('MUX_S2',(46.215,35.85)),('MUX_EN',(44.945,35.85))]:
 net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==name)
 comp,w=windows(b,net,pt,box(15,23,57,65),power)
 print(name,w,flush=True);result[name]=w
Path('/workspace/scratch/d094b9146fd7/round2/control-removals.json').write_text(json.dumps({'ids':{n:sorted(v) for n,v in ids.items()},'windows':result},indent=2))
