import sys,json,time,shutil,itertools
from pathlib import Path
sys.path.insert(0,str(Path('nbfm1-open-bci/hardware/eeg128-tdm').resolve()))
import pcbnew
from merge_native_closure import copper
from route_targeted_closure import search,add_path
from audit_block1_corridor_geometry import outlines
from shapely.geometry import Polygon
from shapely.ops import unary_union
root=Path.cwd();src=root/'joint139-independent';out=root/'probe139-buses-existing-b';out.mkdir(exist_ok=True)
a=copper((root/'baseline141/eeg128-tdm.kicad_pcb').read_text());z=copper((root/'p141-bus-existing-f/eeg128-tdm.kicad_pcb').read_text());s=(src/'eeg128-tdm.kicad_pcb').read_text();original=copper(s)
changes={u:{'before':v,'after':z.get(u,'')} for u,v in a.items() if z.get(u)!=v}; additions={u:v for u,v in z.items() if u not in a}
for u,c in changes.items():assert original[u]==c['before'];s=s.replace(c['before'],c['after'],1)
s=s[:s.rfind(')')]+'\n'+'\n'.join(additions.values())+'\n)\n'
for ext in ['.kicad_pro','.kicad_dru','.kicad_sch']:shutil.copy2(src/('eeg128-tdm'+ext),out/('eeg128-tdm'+ext))
p=out/'eeg128-tdm.kicad_pcb';p.write_text(s)
b=pcbnew.LoadBoard(str(p));codes={p.GetNetname():p.GetNetCode() for f in b.GetFootprints() for p in f.Pads()};zone=unary_union([Polygon(p) for z in outlines(b).values() if pcbnew.In2_Cu in z['layers'] for p in z['outlines']]).buffer(.505)
base=json.loads((root/'probe139-buses/p-plan.json').read_text());route=base['routes'][0]['path']
ends={'MUX_S2':((23.68,37.1),(46.215,35.85)),'MUX_S3':((26.4572,37.8222),(47.485,35.85)),'MUX_EN':((24.8847,34.2644),(44.945,35.85))}
for k,order in enumerate(itertools.permutations(ends)):
 b=pcbnew.LoadBoard(str(p));add_path(b,route,codes['CH018_P_MUX'],.15,.6,layers=(pcbnew.F_Cu,pcbnew.B_Cu));routes=list(base['routes'])
 for name in order:
  start,end=ends[name];path=search(b,start,end,codes[name],.15,.15,True,18,step=.025,max_nodes=1800000,deadline=time.monotonic()+45,start_layer=(1 if name in ['MUX_S2','MUX_S3'] else 0),goal_layer=0,layers=(pcbnew.F_Cu,pcbnew.B_Cu),via_diameter=.6,via_keepout=zone)
  print({'case':k,'net':name,'found':bool(path),'points':len(path) if path else 0},flush=True)
  routes.append({'net':name,'layers':['F.Cu','B.Cu'],'path':path})
  if not path:break
  add_path(b,path,codes[name],.15,.6,layers=(pcbnew.F_Cu,pcbnew.B_Cu))
 result={**base,'routes':routes,'complete':len(routes)==4 and all(r['path'] for r in routes)};(out/f'case{k}-plan.json').write_text(json.dumps(result,indent=2))
 if result['complete']:break
