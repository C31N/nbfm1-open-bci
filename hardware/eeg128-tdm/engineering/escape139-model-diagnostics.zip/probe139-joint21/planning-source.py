import sys,json,time,shutil
from pathlib import Path
sys.path.insert(0,str(Path('nbfm1-open-bci/hardware/eeg128-tdm').resolve()))
import pcbnew
from route_targeted_closure import search,add_path,xy,obstacles
from merge_native_closure import copper
from audit_block1_corridor_geometry import outlines
from shapely.geometry import Polygon,box,Point
from shapely.ops import unary_union
r=Path.cwd();out=r/'probe139-joint21';out.mkdir(exist_ok=True);text=(r/'joint139-independent/eeg128-tdm.kicad_pcb').read_text();old=copper(text);target=json.loads((r/'probe139-target21/windows.json').read_text());local=json.loads((r/'probe139-c22-local/apply-plan.json').read_text());c22=local['routes'][0]
for case in [2,1,5]:
 row=target['rows'][case];s=text;changes=dict(local['changes'])
 for u in row['removed_uuids']:changes[u]={'before':old[u],'after':''}
 for c in changes.values():s=s.replace(c['before'],c['after'],1)
 p=out/f'model{case}.kicad_pcb';p.write_text(s);b=pcbnew.LoadBoard(str(p));codes={p.GetNetname():p.GetNetCode() for f in b.GetFootprints() for p in f.Pads()};add_path(b,c22['path'],codes[c22['net']],.15,.6,layers=(pcbnew.F_Cu,pcbnew.In2_Cu));zone=unary_union([Polygon(p) for z in outlines(b).values() if pcbnew.In2_Cu in z['layers'] for p in z['outlines']]).buffer(.505);routes=[c22]
 # CH021 via-aware source escape uses the newly opened fixed source window.
 neck=search(b,(36.15,18.2),(35.6,17.275),codes['CH021_N_ELECTRODE'],.15,.15,False,3,step=.01,max_nodes=300000,deadline=time.monotonic()+20,start_layer=0,goal_layer=0,layers=(pcbnew.F_Cu,pcbnew.In2_Cu),via_diameter=.6,via_keepout=zone)
 if not neck:print({'case':case,'failed':'source-neck'},flush=True);continue
 add_path(b,neck,codes['CH021_N_ELECTRODE'],.15,.6,layers=(pcbnew.F_Cu,pcbnew.In2_Cu));routes.append({'net':'CH021_N_ELECTRODE','layers':['F.Cu','In2.Cu'],'path':neck})
 trunk=search(b,(35.6,17.275),(43.25,7.6),codes['CH021_N_ELECTRODE'],.15,.15,True,13,step=.025,max_nodes=2200000,deadline=time.monotonic()+55,start_layer=1,goal_layer=0,layers=(pcbnew.F_Cu,pcbnew.In2_Cu),via_diameter=.6,via_keepout=zone,reserved_bottom=unary_union([Polygon(p) for z in outlines(b).values() if pcbnew.In2_Cu in z['layers'] for p in z['outlines']]).buffer(.05))
 print({'case':case,'stage':'trunk','found':bool(trunk),'points':len(trunk) if trunk else 0},flush=True)
 if trunk:
  routes.append({'net':'CH021_N_ELECTRODE','layers':['F.Cu','In2.Cu'],'path':[[0,35.6,17.275]]+trunk});add_path(b,[[0,35.6,17.275]]+trunk,codes['CH021_N_ELECTRODE'],.15,.6,layers=(pcbnew.F_Cu,pcbnew.In2_Cu))
  for net,via,pad in [('CH023_N_ELECTRODE',(41.5,6.429999),(44.25,7.6)),('CH022_N_ELECTRODE',(41.3,11.68),(43.75,7.6))]:
   if net not in row['removed_nets']:continue
   # Infer the removed path's old via attachment from the actual copper.
   original=pcbnew.LoadBoard(str(r/'joint139-independent/eeg128-tdm.kicad_pcb'))
   anchors=[xy(t.GetPosition()) for t in original.GetTracks() if isinstance(t,pcbnew.PCB_VIA) and t.GetNetname()==net and any(Point(xy(t.GetPosition())).distance(__import__('shapely').geometry.LineString([xy(q.GetStart()),xy(q.GetEnd())]))<1e-6 for q in original.GetTracks() if q.m_Uuid.AsString() in row['removed_uuids'])];print({'case':case,'net':net,'anchors':anchors},flush=True)
   via=anchors[0];path=search(b,via,pad,codes[net],.15,.15,False,13,step=.01,max_nodes=1600000,deadline=time.monotonic()+40,start_layer=0,goal_layer=0,layers=(pcbnew.F_Cu,pcbnew.In2_Cu),via_diameter=.6,via_keepout=zone)
   routes.append({'net':net,'layers':['F.Cu','In2.Cu'],'path':path});print({'case':case,'restore':net,'found':bool(path),'points':len(path) if path else 0},flush=True)
   if not path:break
   add_path(b,path,codes[net],.15,.6,layers=(pcbnew.F_Cu,pcbnew.In2_Cu))
 complete=bool(trunk) and all(q['path'] for q in routes) and len(routes)==3+len(row['removed_nets'])
 (out/f'case{case}-plan.json').write_text(json.dumps({'changes':changes,'routes':routes,'complete':complete,'model_only':True,'accepted':False},indent=2));print({'case':case,'complete':complete},flush=True)
 if complete:break
