import sys,json,time
from pathlib import Path
sys.path.insert(0,str(Path('nbfm1-open-bci/hardware/eeg128-tdm').resolve()))
import pcbnew
from route_targeted_closure import search,xy
from merge_native_closure import copper
from audit_block1_corridor_geometry import outlines
from shapely.geometry import Polygon
from shapely.ops import unary_union
r=Path.cwd();out=r/'probe139-c20-bridge';out.mkdir(exist_ok=True);text=(r/'joint139-independent/eeg128-tdm.kicad_pcb').read_text();old=copper(text);b=pcbnew.LoadBoard(str(r/'joint139-independent/eeg128-tdm.kicad_pcb'));changes={t.m_Uuid.AsString():{'before':old[t.m_Uuid.AsString()],'after':''} for t in b.GetTracks() if t.GetNetname()=='CH020_N_ELECTRODE' and not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()==pcbnew.In2_Cu}
for c in changes.values():text=text.replace(c['before'],'',1)
p=out/'model.kicad_pcb';p.write_text(text);b=pcbnew.LoadBoard(str(p));codes={p.GetNetname():p.GetNetCode() for f in b.GetFootprints() for p in f.Pads()};zone=unary_union([Polygon(p) for z in outlines(b).values() if pcbnew.In2_Cu in z['layers'] for p in z['outlines']])
for both in [False,True]:
 path=search(b,(35.6,19.879999),(42.3,6.429999),codes['CH020_N_ELECTRODE'],.15,.15,both,15,step=.025,max_nodes=2000000,deadline=time.monotonic()+50,start_layer=1,goal_layer=1,layers=(pcbnew.F_Cu,pcbnew.B_Cu),via_diameter=.6,via_keepout=zone.buffer(.505));print({'both':both,'found':bool(path)},flush=True)
 if path:break
(out/'plan.json').write_text(json.dumps({'changes':changes,'routes':[{'net':'CH020_N_ELECTRODE','layers':['F.Cu','B.Cu'],'path':path}],'complete':bool(path),'model_only':True,'accepted':False},indent=2))
