import sys,json,time,itertools
from pathlib import Path
sys.path.insert(0,str(Path('nbfm1-open-bci/hardware/eeg128-tdm').resolve()))
import pcbnew
from route_targeted_closure import add_path,search
from audit_block1_corridor_geometry import outlines
from shapely.geometry import Polygon
from shapely.ops import unary_union
r=Path.cwd();out=r/'probe139-wide-restored';out.mkdir(exist_ok=True);data=json.loads((r/'probe139-joint21-wide/case2-plan.json').read_text());fixed=[q for q in data['routes'] if q['path']];print({'fixed':len(fixed)},flush=True)
for case,(order,firstlayer) in enumerate(itertools.product([('C26','C23'),('C23','C26')],[0,1,2])):
 b=pcbnew.LoadBoard(str(r/'probe139-joint21-wide/model2.kicad_pcb'));codes={p.GetNetname():p.GetNetCode() for f in b.GetFootprints() for p in f.Pads()};zone=unary_union([Polygon(p) for z in outlines(b).values() if pcbnew.In2_Cu in z['layers'] for p in z['outlines']]);routes=list(fixed)
 for q in fixed:add_path(b,q['path'],codes[q['net']],.15,.6,layers=tuple(b.GetLayerID(x) for x in q['layers']))
 for short in order:
  name,a,z=('CH026_P_ELECTRODE',(35.4508,14.8346),(41.15,18.2)) if short=='C26' else ('CH023_N_ELECTRODE',(41.5,6.429999),(44.25,7.6));route=None
  approaches=[('F-B',firstlayer if firstlayer<2 else 0),('F-L3',1 if firstlayer==2 else 0),('F-B',1 if firstlayer==0 else 0)]
  for kind,start in approaches:
   layers=(pcbnew.F_Cu,pcbnew.B_Cu if kind=='F-B' else pcbnew.In2_Cu)
   p=search(b,a,z,codes[name],.15,.15,True,15,step=.025,max_nodes=1800000,deadline=time.monotonic()+40,start_layer=start,goal_layer=0,layers=layers,via_diameter=.6,via_keepout=zone.buffer(.505),reserved_bottom=zone.buffer(.05) if kind=='F-L3' else None)
   print({'case':case,'net':name,'kind':kind,'start':start,'found':bool(p)},flush=True)
   if p:route={'net':name,'layers':[b.GetLayerName(x) for x in layers],'path':p};break
  routes.append(route or {'net':name,'path':None})
  if not route:break
  add_path(b,route['path'],codes[name],.15,.6,layers=tuple(b.GetLayerID(x) for x in route['layers']))
 complete=len(routes)==len(fixed)+2 and all(q['path'] for q in routes);(out/f'case{case}-plan.json').write_text(json.dumps({**data,'routes':routes,'complete':complete,'accepted':False},indent=2));print({'case':case,'complete':complete},flush=True)
 if complete:break
