import sys,json,math,subprocess,heapq
from pathlib import Path
sys.path.insert(0,str(Path('nbfm1-open-bci/hardware/eeg128-tdm').resolve()))
import pcbnew
from route_targeted_closure import obstacles,add_path,make_via,search,xy
from audit_block1_corridor_geometry import outlines
from merge_native_closure import copper
from shapely.geometry import box,Point,Polygon
from shapely.ops import unary_union
from shapely.strtree import STRtree
r=Path.cwd();out=r/'probe139-joint21-graph';out.mkdir(exist_ok=True)
s=(r/'solve-joint1718-precise-spread140.py').read_text();func=s[s.index('def mesh('):s.index('for f_order in ')];func=func.replace('for i in [1,2] for j,p in enumerate(parts[i]) if p.covers(Point(z))','for i in [0] for j,p in enumerate(parts[i]) if p.covers(Point(z))');exec(func)
base=(r/'joint139-independent/eeg128-tdm.kicad_pcb').read_text();old=copper(base);window=json.loads((r/'probe139-target21/windows.json').read_text());local=json.loads((r/'probe139-c22-local/apply-plan.json').read_text());c22=local['routes'][0]
for case in [2,1,5]:
 row=window['rows'][case];text=base;changes=dict(local['changes']);changes.update({u:{'before':old[u],'after':''} for u in row['removed_uuids']})
 for c in changes.values():text=text.replace(c['before'],c['after'],1)
 p=out/f'model{case}.kicad_pcb';p.write_text(text);b=pcbnew.LoadBoard(str(p));codes={p.GetNetname():p.GetNetCode() for f in b.GetFootprints() for p in f.Pads()};add_path(b,c22['path'],codes[c22['net']],.15,.6,layers=(pcbnew.F_Cu,pcbnew.In2_Cu));zone=unary_union([Polygon(p) for z in outlines(b).values() if pcbnew.In2_Cu in z['layers'] for p in z['outlines']]);routes=[c22]
 neck=search(b,(36.15,18.2),(35.6,17.275),codes['CH021_N_ELECTRODE'],.15,.15,False,3,step=.01,max_nodes=300000,deadline=__import__('time').monotonic()+20,start_layer=0,goal_layer=0,layers=(pcbnew.F_Cu,pcbnew.In2_Cu),via_diameter=.6)
 assert neck;routes.append({'net':'CH021_N_ELECTRODE','layers':['F.Cu','In2.Cu'],'path':neck});add_path(b,neck,codes['CH021_N_ELECTRODE'],.15,.6,layers=(pcbnew.F_Cu,pcbnew.In2_Cu));make_via(b,(35.6,17.275),codes['CH021_N_ELECTRODE'],.6)
 found=trunk(b,'CH021_N_ELECTRODE',(35.6,17.275),(43.25,7.6),f'case{case}-trunk',zone);print({'case':case,'graph_found':bool(found)},flush=True)
 if found:
  legs,vias,nodes=found;routes.extend(legs);routes.append({'net':'CH021_N_ELECTRODE','layers':['F.Cu',['F.Cu','B.Cu','In2.Cu'][nodes[0][0]]],'path':[[0,35.6,17.275],[1,35.6,17.275]]})
  for q in legs:add_path(b,q['path'],codes[q['net']],.15,.6,layers=tuple(b.GetLayerID(x) for x in q['layers']))
  for k,v in enumerate(vias):make_via(b,v,codes['CH021_N_ELECTRODE'],.6);routes.append({'net':'CH021_N_ELECTRODE','layers':[['F.Cu','B.Cu','In2.Cu'][nodes[k][0]],['F.Cu','B.Cu','In2.Cu'][nodes[k+1][0]]],'path':[[0,*v],[1,*v]]})
  original=pcbnew.LoadBoard(str(r/'joint139-independent/eeg128-tdm.kicad_pcb'))
  for net,pad in [('CH023_N_ELECTRODE',(44.25,7.6)),('CH022_N_ELECTRODE',(43.75,7.6))]:
   if net not in row['removed_nets']:continue
   anchors=[xy(t.GetPosition()) for t in original.GetTracks() if isinstance(t,pcbnew.PCB_VIA) and t.GetNetname()==net and any(Point(xy(t.GetPosition())).distance(__import__('shapely').geometry.LineString([xy(q.GetStart()),xy(q.GetEnd())]))<1e-6 for q in original.GetTracks() if q.m_Uuid.AsString() in row['removed_uuids'])]
   path=search(b,anchors[0],pad,codes[net],.15,.15,False,13,step=.01,max_nodes=1200000,deadline=__import__('time').monotonic()+35,start_layer=0,goal_layer=0,layers=(pcbnew.F_Cu,pcbnew.In2_Cu),via_diameter=.6)
   routes.append({'net':net,'layers':['F.Cu','In2.Cu'],'path':path});print({'case':case,'restore':net,'anchors':anchors,'found':bool(path)},flush=True)
   if not path:break
   add_path(b,path,codes[net],.15,.6,layers=(pcbnew.F_Cu,pcbnew.In2_Cu))
 complete=found is not None and len([q for q in routes if q['net'] in row['removed_nets'] and q['path']])==len(row['removed_nets']);(out/f'case{case}-plan.json').write_text(json.dumps({'changes':changes,'routes':routes,'complete':complete,'model_only':True,'accepted':False},indent=2));print({'case':case,'complete':complete},flush=True)
 if complete:break
