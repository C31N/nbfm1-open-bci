import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy,native_fresh,metrics
from replay_block2_source_window import MEMBERS
from merge_native_closure import copper
root=Path('/workspace/scratch/d094b9146fd7/round3');src=root/'joint137-clean';out=root/'joint137-final2';out.mkdir(exist_ok=False);b=pcbnew.LoadBoard(str(src/'eeg128-tdm.kicad_pcb'));removed=[]
for t in b.GetTracks():
 if t.GetNetname()!='CH017_N_MUX':continue
 if isinstance(t,pcbnew.PCB_VIA):remove=t.m_Uuid.AsString()=='21548a14-551d-4062-8b9f-c24eb62ac5f8'
 else:remove=(t.GetLayer()==pcbnew.B_Cu and max(xy(t.GetStart())[1],xy(t.GetEnd())[1])<30) or (t.GetLayer()==pcbnew.F_Cu and any(abs(p[0]-37.5)<.000002 and abs(p[1]-29.549999)<.000002 for p in [xy(t.GetStart()),xy(t.GetEnd())]))
 if remove:removed.append(t.m_Uuid.AsString())
text=(src/'eeg128-tdm.kicad_pcb').read_text();items=copper(text)
for uid in removed:text=text.replace(items[uid],'',1)
for n in MEMBERS:shutil.copy2(src/n,out/n)
(out/'eeg128-tdm.kicad_pcb').write_text(text);(out/'cleanup.json').write_text(json.dumps({'removed_uuids':removed,'reason':'Remove bypassed source dogleg and its obsolete via; retain the original R-pad via as F.Cu/In2.Cu transition.','accepted':False},indent=2));print('REMOVED',len(removed),flush=True);print(metrics(native_fresh(out/'eeg128-tdm.kicad_pcb',out/'drc.json')),flush=True)
