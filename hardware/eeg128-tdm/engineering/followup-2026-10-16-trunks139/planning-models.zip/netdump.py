import sys
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy
b=pcbnew.LoadBoard('/workspace/scratch/d094b9146fd7/round2/controls-native/eeg128-tdm.kicad_pcb')
for t in b.GetTracks():
 if t.GetNetname() in sys.argv[1:]:print(t.GetNetname(),t.m_Uuid.AsString(),b.GetLayerName(t.GetLayer()),'VIA' if isinstance(t,pcbnew.PCB_VIA) else '',xy(t.GetStart()),xy(t.GetEnd()))
