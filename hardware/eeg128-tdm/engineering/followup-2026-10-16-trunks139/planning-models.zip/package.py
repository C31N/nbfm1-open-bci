from pathlib import Path
import shutil,zipfile,json
r=Path('/workspace/scratch/d094b9146fd7/round3');repo=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm');out=repo/'engineering/followup-2026-10-16-trunks139'
for case,sub in [('p','replay-p138-final'),('n','replay-n138'),('joint','replay-joint137-final')]:
 for src,dst in [('drc-after.json',f'{case}-drc.json'),('parity.json',f'{case}-parity.json'),('result.json',f'{case}-result.json')]:shutil.copy2(r/sub/src,out/dst)
shutil.copy2(r/'replay-joint137-final/drc-before.json',out/'baseline-drc.json');shutil.copy2(r/'replay139/result.json',out/'baseline-replay-result.json');shutil.copy2(r/'isolated-tests-summary.json',out/'isolated-tests-summary.json');shutil.copy2(r/'pytest.log',out/'pytest.log')
shutil.copy2(r/'p18-replay/result.json',out/'rejected-p18-result.json');shutil.copy2(r/'p18-exact/power-delta.json',out/'rejected-p18-power.json')
# Archive bounded search proposals, failed native diagnostics and planning sources.
files=list(r.glob('*.py'))+list(r.glob('*topology-*.json'))+list(r.glob('*topology-*.log'))
for sub in ['p17-0','p18-3','p17mux-3','p18-clean','p18-exact','p18local-0','n17-1','n20-0','n20-first-0','n17local-0','joint137-0','joint137-clean','joint137-final','joint137-final2','p18-replay']:
 for name in ['plan.json','drc.json','drc-before.json','drc-after.json','parity.json','copper-delta.json','power-delta.json','result.json','cleanup.json']:
  p=r/sub/name
  if p.is_file():files.append(p)
with zipfile.ZipFile(out/'planning-models.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):
  entry=zipfile.ZipInfo(str(p.relative_to(r)),(2026,10,16,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,p.read_bytes())
print('packaged',len(files),'planning files')
