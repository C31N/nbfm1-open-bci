import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh import mesh_route,add_mesh_path
from analyze_139_escape_blockers import protected_power
from route_targeted_closure import make_via,native_fresh,metrics
from shapely.geometry import box
root=Path('/workspace/scratch/d094b9146fd7/round3');base=Path('/workspace/scratch/d094b9146fd7/round2/controls-native/eeg128-tdm.kicad_pcb');b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(12,.5,59,69);case=int(sys.argv[1]);removed=[]
for t in list(b.GetTracks()):
 if t.GetNetname()=='CH018_N_MUX' and not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()==pcbnew.In2_Cu:removed.append(t);b.Remove(t)
sv=[(32.2625,35.646231),(33.637364,19.491039),(33.003947,22.037563)][case%3];tv=(46.841954,34.399999);main='CH018_P_MUX'
requests=[(main,(32.75,26),sv,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,sv),(main,(41.135,45.15),tv,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,tv),(main,sv,tv,(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True,None),('CH018_N_MUX',(38.847,27.058),(42.85,53.129999),(pcbnew.F_Cu,pcbnew.B_Cu),0,0,case>=3,None)]
paths=[]
for i,(name,start,goal,layers,sl,gl,allow,via) in enumerate(requests):
 net=b.FindNet(name).GetNetCode();path=mesh_route(b,start,goal,net,layers,power,region,sl,gl,allow);print(i,name,path is not None,flush=True);paths.append({'net':name,'layers':[b.GetLayerName(l) for l in layers],'path':path})
 if path is None:break
 add_mesh_path(b,path,net,layers)
 if via:make_via(b,via,net,.6)
out=root/f'p18-{case}';out.mkdir(exist_ok=True);r={'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'complete':len(paths)==4 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 target=out/base.name;pcbnew.SaveBoard(str(target),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
 d=native_fresh(target,out/'drc.json');print('NATIVE',metrics(d),flush=True)
