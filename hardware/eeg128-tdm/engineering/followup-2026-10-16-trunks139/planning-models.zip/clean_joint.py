import sys,shutil,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
from merge_native_closure import copper
from route_targeted_closure import native_fresh,metrics
from replay_block2_source_window import MEMBERS
root=Path('/workspace/scratch/d094b9146fd7/round3');src=root/'joint137-0';out=root/'joint137-clean';out.mkdir(exist_ok=False)
for n in MEMBERS:shutil.copy2(src/n,out/n)
p=out/'eeg128-tdm.kicad_pcb';text=p.read_text();block=copper(text)['d6dec544-1342-4a1a-8246-72d423e83eea'];assert block.startswith('(via');p.write_text(text.replace(block,'',1));print(metrics(native_fresh(p,out/'drc.json'))),
