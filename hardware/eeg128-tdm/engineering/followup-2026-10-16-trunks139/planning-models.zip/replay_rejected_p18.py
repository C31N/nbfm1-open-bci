import sys,hashlib,json,shutil,zipfile
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
from replay_ch019_electrode import clean,geometry
from route_targeted_closure import native_fresh
from replay_block2_source_window import MEMBERS,reproducible_zip
from merge_native_closure import copper
from replay_ch018_neighbors import validate_vias
root=Path('/workspace/scratch/d094b9146fd7/round3');source=root/'p18-exact';out=root/'p18-replay';out.mkdir(exist_ok=False);archive=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm/engineering/block2-ch019-electrode-closed139.zip');digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert digest(archive)=='f022d711bf860c6ec9383dae6f511c41189bf7348035d8d1e5e0e0ca6bcd6d1b'
with zipfile.ZipFile(archive) as z:
 for n in MEMBERS:(out/n).write_bytes(z.read(n))
ref=out/'reference';ref.mkdir()
for n in MEMBERS:shutil.copy2(out/n,ref/n)
name='eeg128-tdm.kicad_pcb';clean(native_fresh(ref/name,out/'drc-before.json'),139);data=json.loads((source/'copper-delta.json').read_text());text=(out/name).read_text();old=copper(text)
for uid,c in data['changes'].items():
 assert old[uid]==c['before'];text=text.replace(c['before'],c['after'],1)
text=text[:text.rfind(')')]+'\n'+'\n'.join(data['additions'].values())+'\n)\n';validate_vias(copper(text),set(data['changes'])|set(data['additions']));(out/name).write_text(text);clean(native_fresh(out/name,out/'drc-after.json'),138);assert (out/name).read_bytes()==(source/name).read_bytes()
try:geometry(ref/name,out/name,data)
except ValueError as e:
 assert str(e)=='Filled L3 power changed; no numerical tolerance is permitted';reason=str(e)
else:raise AssertionError('Expected exact power rejection')
reproducible_zip(out,out/'rejected.zip');r={'accepted':False,'routing_completed':False,'fabrication_release':False,'byte_identical_pcb_replay':True,'violations':0,'warnings':0,'unconnected':138,'rejection':reason,'pcb_sha256':digest(out/name),'archive_sha256':digest(out/'rejected.zip')};(out/'result.json').write_text(json.dumps(r,indent=2));print(r)
