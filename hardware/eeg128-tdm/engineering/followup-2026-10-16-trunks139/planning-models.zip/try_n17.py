import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy,make_via,obstacles
from analyze_139_escape_blockers import protected_power
from escape_mesh import mesh_route,add_mesh_path
from shapely.geometry import box,Point
case=int(sys.argv[1]);root=Path('/workspace/scratch/d094b9146fd7/round3');base=Path('/workspace/scratch/d094b9146fd7/work139/eeg128-tdm.kicad_pcb');b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(25,.5,57,35.9)
src='CH027_P_ELECTRODE';tgt='CH023_N_ELECTRODE';main='CH021_N_ELECTRODE';removed=[]
remove_starts={(33.55,16.279999),(33.65,16.379999),(33.95,16.379999),(35.45,17.879999),(35.45,18.879999),(35.55,18.979999),(37.65,18.979999)}
for t in b.GetTracks():
 x,y=xy(t.GetStart()),xy(t.GetEnd());remove=False
 if t.GetNetname()==src and not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()==pcbnew.F_Cu and x in remove_starts:remove=True
 if t.GetNetname()==tgt:
  if isinstance(t,pcbnew.PCB_VIA):remove=x!=(36.55,11.979999)
  elif t.GetLayer()==pcbnew.In2_Cu:remove=True
  else:remove=min(x[0],y[0])>40
 if remove:removed.append(t)
for t in b.GetTracks():
 if t.GetNetname()=='CH017_N_ELECTRODE' and not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()==pcbnew.B_Cu:removed.append(t)
for t in removed:b.Remove(t)

import itertools
v27=(33.003947,22.037563);v21=(33.637364,19.491039);v23=(50.4762,8.808369);tv21=(52.707002,7.486252)
requests=[(main,(36.15,18.2),v21,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,v21),
          (src,(33.55,16.279999),v27,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,v27),
          (tgt,(44.25,7.6),v23,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,v23),
          (main,(43.25,7.6),tv21,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,tv21)]
trunks=[(src,v27,(38.15,19.479999),(pcbnew.F_Cu,pcbnew.B_Cu),1,1,True,None),
        (tgt,(36.55,11.979999),v23,(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True,None),
        (main,v21,tv21,(pcbnew.B_Cu,pcbnew.In2_Cu),0,0,True,None)]
order=list(itertools.permutations(range(3)))[case];requests += [trunks[i] for i in order];requests.append(('CH017_N_ELECTRODE',(37.344255,27.176452),(38.843033,19.120389),(pcbnew.F_Cu,pcbnew.B_Cu),0,0,True,None));paths=[]
for i,(name,start,goal,layers,sl,gl,allow,via) in enumerate(requests):
 net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==name)
 if via:
  _,obs=obstacles(b,net,.15,.15,region,.6,layers)
  if obs.covers(Point(via)) or power.buffer(.505).covers(Point(via)):
   print('via blocked',name,via,flush=True);paths.append({'net':name,'path':None,'reason':'via blocked'});break
 path=mesh_route(b,start,goal,net,layers,power,region,start_layer=sl,goal_layer=gl,allow_vias=allow)
 print(i,name,path is not None,flush=True);paths.append({'net':name,'layers':[b.GetLayerName(l) for l in layers],'path':path})
 if not path:break
 add_mesh_path(b,path,net,layers)
 if via:make_via(b,via,net,.6)
out=root/f'n17-{case}';out.mkdir(exist_ok=True);r={'case':case,'source_via21':v21,'source_via27':v27,'target_via23':v23,'target_via21':tv21,'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'complete':len(paths)==8 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 target=out/base.name;pcbnew.SaveBoard(str(target),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),target.with_suffix(ext))
 from route_targeted_closure import native_fresh,metrics
 d=native_fresh(target,out/'drc.json');print('NATIVE',metrics(d),flush=True)
