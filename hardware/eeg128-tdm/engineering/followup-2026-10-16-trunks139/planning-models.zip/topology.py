import sys,json,time
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from shapely.geometry import box,Point,LineString
from shapely.ops import unary_union
from escape_mesh import polygons
from analyze_139_escape_blockers import protected_power
from route_targeted_closure import obstacles,xy
root=Path('/workspace/scratch/d094b9146fd7/round3')
case=sys.argv[1];base=Path('/workspace/scratch/d094b9146fd7/round2')/('controls-native' if case=='p' else 'header-clean')/'eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(.5,.5,95,130)
name='CH018_P_MUX' if case=='p' else 'CH021_N_ELECTRODE';net=b.FindNet(name).GetNetCode();layers=(pcbnew.B_Cu,pcbnew.In2_Cu)
anchors=([(46.841954,34.399999),(32.2625,35.646231),(32.930481,29.903291),(31.5525,27.275981),(33.003947,22.037563),(33.637364,19.491039),(28.4875,34.7)] if case=='p' else [(52.707002,7.486252),(33.637364,19.491039),(35.6,17.275)])
def run():
 blocked,via=obstacles(b,net,.15,.15,region,.6,layers);blocked[1]=unary_union([blocked[1],power.buffer(.280)])
 free=[polygons(region.difference(s).buffer(-.000005)) for s in blocked]; vf=region.difference(unary_union([via,power.buffer(.505)])).buffer(-.000005)
 nodes={};adj={};patches=[]
 for l,ps in enumerate(free):
  for i,p in enumerate(ps):nodes[l,i]=p;adj[l,i]=set()
 for patch in polygons(vf):
  if patch.area<1e-10:continue
  pt=patch.representative_point();ids=[next(((l,i) for i,p in enumerate(free[l]) if p.covers(pt)),None) for l in range(2)]
  if all(v is not None for v in ids):
   adj[ids[0]].add(ids[1]);adj[ids[1]].add(ids[0]);patches.append((ids,patch.area,tuple(pt.coords[0])))
 reached=set();q=[next(((0,i) for i,p in enumerate(free[0]) if p.covers(Point(anchors[0]))),None)]
 while q:
  n=q.pop()
  if n is None or n in reached:continue
  reached.add(n);q.extend(adj[n]-reached)
 return {'components':[len(ps) for ps in free],'patches':len(patches),'reachable_components':[{'layer':b.GetLayerName(layers[l]),'id':i,'area':nodes[l,i].area,'bounds':nodes[l,i].bounds} for l,i in sorted(reached)],'anchors':[{'point':pt,'components':[i for i,p in enumerate(free[0]) if p.covers(Point(pt))],'reachable':any((0,i) in reached and p.covers(Point(pt)) for i,p in enumerate(free[0]))} for pt in anchors]},[nodes[n] for n in reached]
result,reachable=run();print('BASE',result,flush=True)
neighbors={}
for t in b.GetTracks():
 if t.GetNetCode()==net:continue
 if not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer() not in layers:continue
 shape=Point(xy(t.GetPosition())) if isinstance(t,pcbnew.PCB_VIA) else LineString([xy(t.GetStart()),xy(t.GetEnd())])
 d=min((shape.distance(p) for p in reachable),default=100)
 if d<.7:neighbors.setdefault(t.GetNetname(),[]).append({'uuid':t.m_Uuid.AsString(),'layer':b.GetLayerName(t.GetLayer()),'start':xy(t.GetStart()),'end':xy(t.GetEnd()),'distance':d})
result['neighbors']=neighbors;result['single_net_removal_models']=[]
for name in sorted(neighbors):
 removed=[t for t in b.GetTracks() if t.GetNetname()==name]
 for t in removed:b.Remove(t)
 r,_=run()
 for t in removed:b.Add(t)
 result['single_net_removal_models'].append({'removed_net':name,'removed_objects':len(removed),**r});print(name,[a['reachable'] for a in r['anchors']],flush=True)
(root/f'topology-{case}.json').write_text(json.dumps({'accepted':False,'model_only':True,'routing_completed':False,'fabrication_release':False,**result},indent=2))
