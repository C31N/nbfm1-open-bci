import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from audit_block1_corridor_geometry import power_copper
r=Path(sys.argv[1]);a=power_copper(pcbnew.LoadBoard('/workspace/scratch/d094b9146fd7/work139/eeg128-tdm.kicad_pcb'));b=power_copper(pcbnew.LoadBoard(str(r/'eeg128-tdm.kicad_pcb')));d={'L3_power_loss_mm2':a.difference(b).area,'L3_power_gain_mm2':b.difference(a).area,'accepted':False};(r/'power-delta.json').write_text(json.dumps(d,indent=2));print(d)
