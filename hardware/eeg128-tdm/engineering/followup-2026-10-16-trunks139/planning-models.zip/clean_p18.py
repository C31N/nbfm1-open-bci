import sys,shutil,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import native_fresh,metrics
from replay_ch019_electrode import geometry
from merge_native_closure import copper
src=Path('/workspace/scratch/d094b9146fd7/round3/p18-3');out=src.parent/'p18-clean';out.mkdir(exist_ok=True);name='eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(src/name))
for t in list(b.GetTracks()):
 if t.m_Uuid.AsString()=='2f802a01-bc54-5774-b5d4-0b9061e92cd1':b.Remove(t)
pcbnew.SaveBoard(str(out/name),b)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2((src/name).with_suffix(ext),(out/name).with_suffix(ext))
d=native_fresh(out/name,out/'drc.json');print('NATIVE',metrics(d),flush=True)
ref=Path('/workspace/scratch/d094b9146fd7/work139')/name;a=copper(ref.read_text());z=copper((out/name).read_text());recipe={'changes':{k:{'before':v,'after':z.get(k,'')} for k,v in a.items() if z.get(k)!=v},'additions':{k:v for k,v in z.items() if k not in a}};(out/'copper-delta.json').write_text(json.dumps(recipe,indent=2));print(geometry(ref,out/name,recipe),flush=True)
