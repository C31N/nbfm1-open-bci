import sys,json,re
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import net_of,xy
from collections import Counter
root=Path('/workspace/scratch/d094b9146fd7/round3');repo=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm');base=pcbnew.LoadBoard('/workspace/scratch/d094b9146fd7/work139/eeg128-tdm.kicad_pcb');result={}
for label,sub in [('p','p17local-0'),('n','n21-clean'),('joint','joint137-final2')]:
 b=pcbnew.LoadBoard(str(root/sub/'eeg128-tdm.kicad_pcb'));d=json.loads((root/sub/'drc.json').read_text());names=Counter(net_of(i) for i in d['unconnected_items']);changednets=['CH018_P_MUX','CH018_N_MUX','CH017_N_MUX','CH021_N_ELECTRODE','CH023_N_ELECTRODE','CH027_P_ELECTRODE','MUX_S1','MUX_S2','MUX_S3','MUX_EN'];rows=[]
 for name in changednets:
  vals=[]
  for board in [base,b]:
   ts=[t for t in board.GetTracks() if t.GetNetname()==name];vals.append({'length_mm':sum(pcbnew.ToMM(t.GetLength()) for t in ts if not isinstance(t,pcbnew.PCB_VIA)),'vias':sum(isinstance(t,pcbnew.PCB_VIA) for t in ts)})
  rows.append({'net':name,'before':vals[0],'after':vals[1],'delta_length_mm':vals[1]['length_mm']-vals[0]['length_mm'],'unconnected':names[name]})
 result[label]={'unconnected':sum(names.values()),'open_mux':sum(c for n,c in names.items() if n.endswith('_MUX')),'open_electrode':sum(c for n,c in names.items() if n.endswith('_ELECTRODE')),'block2_open_nets':{n:c for n,c in sorted(names.items()) if re.search(r'CH0(?:1[7-9]|2[0-9]|3[0-2])_',n)},'net_lengths':rows,'CH018_P_vias':[xy(t.GetPosition()) for t in b.GetTracks() if t.GetNetname()=='CH018_P_MUX' and isinstance(t,pcbnew.PCB_VIA)]}
(repo/'engineering/followup-2026-10-16-trunks139/net-lengths-inventory.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:{n:v for n,v in r.items() if n not in ('net_lengths','CH018_P_vias')} for k,r in result.items()},indent=2))
