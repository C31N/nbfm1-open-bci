import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy
from analyze_139_escape_blockers import protected_power
from shapely.geometry import Point,LineString
root=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm/engineering/followup-2026-10-16-trunks139');d=json.loads((root/'joint-trunks-recipe.json').read_text());b=pcbnew.LoadBoard('/workspace/scratch/d094b9146fd7/round3/joint137-final2/eeg128-tdm.kicad_pcb');power=protected_power(b);via=[];tracks=[]
for t in b.GetTracks():
 if t.m_Uuid.AsString() not in d['additions']:continue
 if isinstance(t,pcbnew.PCB_VIA):
  dist=Point(xy(t.GetPosition())).distance(power);assert dist>=.505;via.append({'uuid':t.m_Uuid.AsString(),'net':t.GetNetname(),'point':xy(t.GetPosition()),'distance_to_power_outline_mm':dist})
 elif t.GetLayer()==pcbnew.In2_Cu:
  dist=LineString([xy(t.GetStart()),xy(t.GetEnd())]).distance(power);assert dist>=.280;tracks.append({'uuid':t.m_Uuid.AsString(),'net':t.GetNetname(),'distance_to_power_outline_mm':dist})
r={'accepted':False,'new_vias':via,'new_In2_tracks':tracks,'new_vias_outside_full_power_outline':True,'new_In2_outside_full_power_outline':True};(root/'new-copper-power-audit.json').write_text(json.dumps(r,indent=2)+'\n');print('new vias',len(via),'minimum power distance',min(v['distance_to_power_outline_mm'] for v in via),'new In2',len(tracks),'min',min(v['distance_to_power_outline_mm'] for v in tracks))
