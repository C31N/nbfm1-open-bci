import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from audit_block1_corridor_geometry import power_copper
from escape_mesh import polygons
r=Path(sys.argv[1]);a=power_copper(pcbnew.LoadBoard('/workspace/scratch/d094b9146fd7/work139/eeg128-tdm.kicad_pcb'));b=power_copper(pcbnew.LoadBoard(str(r/'eeg128-tdm.kicad_pcb')))
for label,s in [('loss',a.difference(b)),('gain',b.difference(a))]:
 print(label,[{'area':p.area,'bounds':p.bounds,'wkt':p.wkt[:400]} for p in polygons(s)])
