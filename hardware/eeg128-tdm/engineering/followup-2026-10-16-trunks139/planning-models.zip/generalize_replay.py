from pathlib import Path
r=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm');p=r/'replay_ch018_pair.py';s=p.read_text().replace('Replay the complete CH018-P pair closure from 139 to an unadopted 138 diagnostic.','Replay complete, unadopted CH018-P and CH021-N trunk diagnostics from 139.')
a=s.index('RECIPE =');z=s.index('Report =',a)
s=s[:a]+'''DIRECTORY = ROOT / 'engineering/followup-2026-10-16-trunks139'
CONFIG = {
    'p': {'recipe': 'ch018-pair-recipe.json',
          'sha256': '23f8302f7c2c87f07f511c1d4b4f4356f66874a6c2f70089332e539182fa895b',
          'scope': 'BLOCK2_CH018_PAIR_CLOSURE_138', 'count': 138,
          'closed': ['CH018_P_MUX'], 'required': {'CH018_P_MUX', 'CH018_N_MUX', 'CH017_N_MUX'},
          'vias': {'CH018_P_MUX'},
          'allowed': {'CH018_P_MUX': {'F.Cu', 'B.Cu', 'In2.Cu'}, 'CH017_N_MUX': {'In2.Cu'},
                      'MUX_S1': {'F.Cu', 'B.Cu'}, 'MUX_S2': {'F.Cu'},
                      'MUX_S3': {'F.Cu'}, 'MUX_EN': {'F.Cu'}}},
    'n': {'recipe': 'ch021-electrode-recipe.json',
          'sha256': 'ca2d944ec29a13d32a5ee84d189e6433eb898332ed7683b15276164f231764d7',
          'scope': 'BLOCK2_CH021_ELECTRODE_CLOSURE_138', 'count': 138,
          'closed': ['CH021_N_ELECTRODE'],
          'required': {'CH021_N_ELECTRODE', 'CH017_N_MUX', 'CH023_N_ELECTRODE', 'CH027_P_ELECTRODE'},
          'vias': {'CH021_N_ELECTRODE', 'CH023_N_ELECTRODE'},
          'allowed': {'CH021_N_ELECTRODE': {'F.Cu', 'B.Cu', 'In2.Cu'},
                      'CH023_N_ELECTRODE': {'F.Cu', 'B.Cu', 'In2.Cu'},
                      'CH027_P_ELECTRODE': {'F.Cu'}, 'CH017_N_MUX': {'In2.Cu'}}},
}
''' + s[z:]
s=s.replace('def recipe() -> Report:',"def recipe(case: str = 'p') -> Report:\n    config = CONFIG[case]\n    source = DIRECTORY / config['recipe']").replace('digest(RECIPE) != RECIPE_SHA256',"digest(source) != config['sha256']").replace('json.loads(RECIPE.read_text())','json.loads(source.read_text())')
s=s.replace("data['scope'] != 'BLOCK2_CH018_PAIR_CLOSURE_138'","data['scope'] != CONFIG[case]['scope']")
s=s.replace('def apply(board: Path, data: Report) -> None:',"def apply(board: Path, data: Report, case: str = 'p') -> None:\n    config = CONFIG[case]\n    allowed = config['allowed']")
s=s.replace('not in ALLOWED','not in allowed').replace('ALLOWED[codes[net]]','allowed[codes[net]]').replace("codes[net] != 'CH018_P_MUX'","codes[net] not in config['vias']")
s=s.replace("parser.add_argument('--output-dir'","parser.add_argument('--case', choices=sorted(CONFIG), required=True)\n    parser.add_argument('--output-dir'")
s=s.replace('data = recipe()','data = recipe(args.case)\n    config = CONFIG[args.case]').replace('apply(board, data)','apply(board, data, args.case)')
s=s.replace("[sys.executable, __file__, '--output-dir'","[sys.executable, __file__, '--case', args.case, '--output-dir'").replace('clean(after, 138)',"clean(after, config['count'])").replace('clean(parity, 138)',"clean(parity, config['count'])")
s=s.replace("{'CH018_P_MUX', 'CH018_N_MUX', 'CH017_N_MUX'} &", "config['required'] &").replace('Connectivity regression or CH018 pair or CH017 neighbor remains open','Connectivity regression or required closed net remains open').replace("'closed_nets': ['CH018_P_MUX']","'case': args.case, 'closed_nets': config['closed']")
(r/'replay_trunks139.py').write_text(s);p.unlink()
p=r/'test_ch018_pair_replay.py';s=p.read_text().replace('replay_ch018_pair','replay_trunks139').replace('class CH018PairGuards(unittest.TestCase):',"class CH018PairGuards(unittest.TestCase):\n    case = 'p'").replace('cls.data = recipe()','cls.data = recipe(cls.case)').replace('apply(path, data)','apply(path, data, self.case)').replace('apply(path, self.data)','apply(path, self.data, self.case)');s=s.replace("if __name__ == '__main__':","class CH021TrunkGuards(CH018PairGuards):\n    case = 'n'\n\n\nif __name__ == '__main__':");(r/'test_trunks139_replay.py').write_text(s);p.unlink()
p=r.parent.parent/'.github/workflows/kicad-native.yml';s=p.read_text().replace('test_ch018_pair_replay.py','test_trunks139_replay.py').replace('hardware/eeg128-tdm/replay_ch018_pair.py \\', 'hardware/eeg128-tdm/replay_trunks139.py --case p \\').replace('Test unadopted CH018 pair replay guards','Test unadopted CH018 pair and CH021 trunk replay guards');s=s.replace('      - name: Test unadopted CH030 probe replay guards', '''      - name: Replay complete unadopted CH021 electrode diagnostic
        run: |
          /usr/bin/python3 hardware/eeg128-tdm/replay_trunks139.py --case n \\
            --output-dir /tmp/ch021-trunk-unadopted-replay

      - name: Test unadopted CH030 probe replay guards''');s=s.replace('Path("/tmp/ch018-pair-unadopted-replay")]','Path("/tmp/ch018-pair-unadopted-replay"), Path("/tmp/ch021-trunk-unadopted-replay")]');extra=''.join('            /tmp/ch021-trunk-unadopted-replay/'+n+'\n' for n in ['drc-before.json','drc-after.json','parity.json','result.json']);s=s.replace('          if-no-files-found: error',extra+'          if-no-files-found: error');p.write_text(s)
