import sys,json,re,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
from merge_native_closure import copper
from replay_block2_source_window import reproducible_zip,MEMBERS
root=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm');out=root/'engineering/followup-2026-10-16-trunks139';candidate=Path('/workspace/scratch/d094b9146fd7/round3/joint137-final2');base=Path('/workspace/scratch/d094b9146fd7/work139');name='eeg128-tdm.kicad_pcb';oldtext=(base/name).read_text();old=copper(oldtext);new=copper((candidate/name).read_text());norm=lambda s:re.sub(r'\s+','',s);changes={k:{'before':v,'after':new.get(k,'')} for k,v in old.items() if norm(new.get(k,''))!=norm(v)};adds={k:v for k,v in new.items() if k not in old};text=oldtext
for c in changes.values():text=text.replace(c['before'],c['after'],1)
text=text[:text.rfind(')')]+'\n'+'\n'.join(adds.values())+'\n)\n';reproducible_zip(candidate,out/'joint-trunks-closed137.zip');digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'scope':'BLOCK2_JOINT_TRUNKS_CLOSURE_137','baseline_archive_sha256':digest(root/'engineering/block2-ch019-electrode-closed139.zip'),'baseline_member_sha256':{n:digest(base/n) for n in MEMBERS},'changes':changes,'additions':adds,'expected_applied_sha256':hashlib.sha256(text.encode()).hexdigest(),'expected_pcb_sha256':digest(candidate/name),'expected_archive_sha256':digest(out/'joint-trunks-closed137.zip'),'routing_completed':False,'fabrication_release':False,'accepted':False};(out/'joint-trunks-recipe.json').write_text(json.dumps(r,indent=2)+'\n');print('recipe',digest(out/'joint-trunks-recipe.json'),'changes/adds',len(changes),len(adds),'expected',r['expected_pcb_sha256'],r['expected_archive_sha256'])
