import sys,shutil,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import native_fresh,metrics
from replay_ch019_electrode import geometry
from merge_native_closure import copper
src=Path('/workspace/scratch/d094b9146fd7/round3/p18-3');out=src.parent/'p17mux-clean';out.mkdir(exist_ok=True);name='eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(src/name))
for t in list(b.GetTracks()):
 if t.m_Uuid.AsString()in ('21548a14-551d-4062-8b9f-c24eb62ac5f8','6e282ae0-bb14-48e3-8c6b-d8f7905f8361'):b.Remove(t)
pcbnew.SaveBoard(str(out/name),b)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2((src/name).with_suffix(ext),(out/name).with_suffix(ext))
d=native_fresh(out/name,out/'drc.json');print('NATIVE',metrics(d),flush=True)
