import sys,json,shutil,math
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh_505 import mesh_route,add_mesh_path
from analyze_139_escape_blockers import protected_power
from route_targeted_closure import xy,make_via,native_fresh,metrics
from shapely.geometry import box
root=Path('/workspace/scratch/d094b9146fd7/round4');case=int(sys.argv[1]);base=root/'base137/eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(12,.5,59,69);name='CH029_N_MUX';removed=[]
for t in list(b.GetTracks()):
 if t.GetNetname()=='CH031_N_MUX' and t.m_Uuid.AsString()!='7637c97e-91bd-4d5f-8647-e847bf82bd59':removed.append(t);b.Remove(t)
sv=(49.440043,29.73001);tv=[(46.323609,27.465318),(48.125859,33.878633),(47.320486,29.792634)][case%3];paths=[];actual={}
requests=[(name,(41.135,48.85),tv,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,'target'),(name,(48.75,26),sv,(pcbnew.F_Cu,pcbnew.B_Cu),0,0,False,'source')]
# Reserve both ends before any trunk or neighbor restoration.
for n,s,g,ls,sl,gl,allow,via in requests:
 net=b.FindNet(n).GetNetCode();p=mesh_route(b,s,g,net,ls,power,region,sl,gl,allow);print(via,p is not None,flush=True);paths.append({'net':n,'layers':[b.GetLayerName(l) for l in ls],'path':p})
 if p is None:break
 add_mesh_path(b,p,net,ls);make_via(b,g,net,.6);actual[via]=next(xy(t.GetPosition()) for t in b.GetTracks() if isinstance(t,pcbnew.PCB_VIA) and t.GetNetCode()==net and math.dist(xy(t.GetPosition()),g)<.000002)
if len(actual)==2:
 trunks=[(name,actual['source'],actual['target'],(pcbnew.B_Cu,pcbnew.In2_Cu),0,0),('CH031_N_MUX',(48.75,31.2),(43.675,48.85),(pcbnew.F_Cu,pcbnew.B_Cu,pcbnew.In2_Cu),0,0)]
 if case>=3:trunks.reverse()
 for n,s,g,ls,sl,gl in trunks:
  net=b.FindNet(n).GetNetCode();p=mesh_route(b,s,g,net,ls,power,region,sl,gl,True);print(n,p is not None,flush=True);paths.append({'net':n,'layers':[b.GetLayerName(l) for l in ls],'path':p})
  if p is None:break
  add_mesh_path(b,p,net,ls)
out=root/f'staged31-{case}';out.mkdir(exist_ok=True);r={'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'complete':len(paths)==4 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 p=out/base.name;pcbnew.SaveBoard(str(p),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),p.with_suffix(ext))
 print('NATIVE',metrics(native_fresh(p,out/'drc.json')),flush=True)
