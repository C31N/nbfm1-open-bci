from pathlib import Path
import json,shutil,zipfile
root=Path('/workspace/scratch/d094b9146fd7/round4');out=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm/engineering/followup-2026-10-16-mux137')
for case in ['s0','p25','joint']:
 for src,dst in [('drc-after.json',f'{case}-drc.json'),('parity.json',f'{case}-parity.json'),('result.json',f'{case}-result.json')]:shutil.copy2(root/('replay-'+case)/src,out/dst)
 shutil.copy2(root/('tests-'+case)/'isolated-tests-summary.json',out/(case+'-tests-summary.json'))
shutil.copy2(root/'replay-joint/drc-before.json',out/'baseline-drc137.json')
for src,dst in [('inventory-verified.json','escape-inventory137.json'),('additional-removal-models.json','additional-removal-models.json'),('trunk24-topology-models.json','trunk24-topology-models.json'),('replay139/result.json','baseline-replay139-result.json'),('replay-base137/result.json','baseline-replay137-result.json'),('ruff.log','ruff.log'),('zero-debt.log','zero-debt.log'),('pytest.log','pytest.log'),('manufacturing-blocked.log','manufacturing-blocked.log'),('identity.log','identity.log'),('eda-integrity.log','eda-integrity.log')]:shutil.copy2(root/src,out/dst)
summary=[]
for p in root.glob('verified-removal-*.json'):
 d=json.loads(p.read_text());summary.append({'removed_nets':d['removed_nets'],'neighbors_restored':False,'accepted':False,'results':{n:{side:v[side]['window'] for side in ['source','target']} for n,v in d['results'].items()}})
(out/'verified-removal-summary.json').write_text(json.dumps({'accepted':False,'model_only':True,'results':summary},indent=2)+'\n')
files=list(root.glob('*.py'))+list(root.glob('*.json'))+list(root.glob('*.log'))
for p in root.iterdir():
 if p.is_dir() and (p/'plan.json').exists():files.append(p/'plan.json')
with zipfile.ZipFile(out/'planning-models.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):
  entry=zipfile.ZipInfo(str(p.relative_to(root)),(2026,10,16,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,p.read_bytes())
print('Planning archive',len(set(files)),'files')
