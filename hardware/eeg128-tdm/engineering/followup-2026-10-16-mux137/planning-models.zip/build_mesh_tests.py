from pathlib import Path
s=Path('hardware/eeg128-tdm/test_escape_mesh.py').read_text().replace('from escape_mesh import','from escape_mesh_505 import').replace("'escape_mesh.obstacles'","'escape_mesh_505.obstacles'")
a=s.index('if __name__')
s=s[:a]+'''    def test_strict_505_inner_track_exclusion(self) -> None:
        power=box(4,4,6,6)
        region=box(0,3.5,10,3.7)
        with patch('escape_mesh_505.obstacles',return_value=([region,Polygon()],Polygon())):
            path=mesh_route(Board(),(1,3.6),(9,3.6),1,(pcbnew.F_Cu,pcbnew.In2_Cu),
                            power,region,start_layer=1,goal_layer=1,allow_vias=False)
        self.assertIsNone(path)
        self.assertGreater(region.difference(power.buffer(.280)).area,0)

    def test_sparse_via_windows_require_all_three_layers(self) -> None:
        region=box(0,0,10,10)
        shapes={pcbnew.F_Cu:box(3,0,3.2,10).union(box(7,0,7.2,10)),
                pcbnew.B_Cu:box(6,0,6.2,10),pcbnew.In2_Cu:box(4,0,4.2,10)}
        legal=box(1.8,4.8,2.2,5.2).union(box(4.8,4.8,5.2,5.2)).union(box(7.8,4.8,8.2,5.2))
        def mock_obstacles(*args: object) -> tuple[list[BaseGeometry], BaseGeometry]:
            layers=args[-1]
            return [shapes[layers[0]],shapes[layers[1]]],region.difference(legal)
        with patch('escape_mesh_505.obstacles',side_effect=mock_obstacles):
            for layers in [(pcbnew.F_Cu,pcbnew.B_Cu),(pcbnew.F_Cu,pcbnew.In2_Cu)]:
                self.assertIsNone(mesh_route(Board(),(1,5),(9,5),1,layers,Polygon(),region))
            path=mesh_route(Board(),(1,5),(9,5),1,
                            (pcbnew.F_Cu,pcbnew.B_Cu,pcbnew.In2_Cu),Polygon(),region)
        self.assertIsNotNone(path)
        self.assertEqual({p[0] for p in path},{0,1,2})


if __name__ == '__main__':
    unittest.main()
'''
Path('hardware/eeg128-tdm/test_escape_mesh_505.py').write_text(s)
