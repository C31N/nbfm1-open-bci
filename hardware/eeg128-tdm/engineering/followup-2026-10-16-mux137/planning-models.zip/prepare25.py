import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh_505 import mesh_route,add_mesh_path
from analyze_139_escape_blockers import windows,protected_power
from route_targeted_closure import xy,native_fresh,metrics
from shapely.geometry import box,Point,LineString,Polygon
from shapely.ops import unary_union
root=Path('/workspace/scratch/d094b9146fd7/round4');case=int(sys.argv[1]);base=root/'base137/eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(12,.5,59,69);removed=[]
for t in list(b.GetTracks()):
 if t.GetNetname()=='CH025_P_MUX' and not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()==pcbnew.F_Cu and min(xy(t.GetStart())[1],xy(t.GetEnd())[1])>33:removed.append(t);b.Remove(t)
future=[(32.825,33.635907),(28.4875,34.7)][case];ls=(pcbnew.F_Cu,pcbnew.B_Cu);net=b.FindNet('CH024_P_MUX').GetNetCode();head=mesh_route(b,(34.785,35.85),future,net,ls,power,region,allow_vias=False);print('reserved CH024 target',head is not None,flush=True);r={'removed':[t.m_Uuid.AsString() for t in removed],'future_via':future,'future_target_path':head,'accepted':False,'routing_completed':False,'fabrication_release':False,'complete':False}
if head:
 reserved=unary_union([LineString([a[1:],c[1:]]).buffer(.300005) for a,c in zip(head,head[1:])]+[Point(future).buffer(.525005)])
 net25=b.FindNet('CH025_P_MUX').GetNetCode();path=mesh_route(b,(34.055,33.299999),(36.055,35.85),net25,ls,power,region,allow_vias=False,extra_obstacles=[reserved,Polygon()]);print('restitution CH025',path is not None,flush=True);r['paths']=[{'net':'CH025_P_MUX','layers':['F.Cu','B.Cu'],'path':path}];r['complete']=path is not None
 if path:add_mesh_path(b,path,net25,ls)
out=root/f'prepare25-{case}';out.mkdir(exist_ok=True);(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 _,w=windows(b,net,(34.785,35.85),region,power);print('WINDOW',w,flush=True);r['restituted_window']=w;(out/'plan.json').write_text(json.dumps(r,indent=2));p=out/base.name;pcbnew.SaveBoard(str(p),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),p.with_suffix(ext))
 print('NATIVE',metrics(native_fresh(p,out/'drc.json')),flush=True)
