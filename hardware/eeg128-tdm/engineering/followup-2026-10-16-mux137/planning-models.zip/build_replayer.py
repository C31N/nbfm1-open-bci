from pathlib import Path
r=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm');s=(r/'replay_trunks139.py').read_text().replace('Replay complete, unadopted CH018-P and CH021-N trunk diagnostics from 139.','Replay complete F.Cu-only S0/CH025 preparatory reroutes on diagnostic 137.')
a=s.index('DIRECTORY =');z=s.index('Report =',a);s=s[:a]+'''DIRECTORY = ROOT / 'engineering/followup-2026-10-16-mux137'
CONFIG = {
    's0': {'recipe': 's0-recipe.json',
           'sha256': '2f7026c0a1ce6df0054cbcb4551442abea52f52b8f4e2b9e70d92d25d675cae3',
           'scope': 'BLOCK2_MUX137_PREPARATION_S0', 'count': 137, 'closed': [],
           'required': {'MUX_S0', 'CH018_P_MUX', 'CH021_N_ELECTRODE'}, 'vias': set(),
           'allowed': {'MUX_S0': {'F.Cu'}}},
    'p25': {'recipe': 'p25-recipe.json',
            'sha256': '3a019822edfd42c0714414865277df25df02c83fa937a7544460e2b10fa06624',
            'scope': 'BLOCK2_MUX137_PREPARATION_P25', 'count': 137, 'closed': [],
            'required': {'CH025_P_MUX', 'CH018_P_MUX', 'CH021_N_ELECTRODE'}, 'vias': set(),
            'allowed': {'CH025_P_MUX': {'F.Cu'}}},
}
'''+s[z:]
s=s.replace("case: str = 'p'","case: str = 's0'").replace("engineering/block2-ch019-electrode-closed139.zip","engineering/followup-2026-10-16-trunks139/joint-trunks-closed137.zip").replace('clean(before, 139)','clean(before, 137)')
(r/'replay_mux137_followup.py').write_text(s)
s=(r/'test_trunks139_replay.py').read_text().replace('replay_trunks139','replay_mux137_followup').replace('CH018PairGuards','S0PreparationGuards').replace("case = 'p'","case = 's0'").replace("cls.baseline = bundle.read('eeg128-tdm.kicad_pcb')","cls.baseline = bundle.read('eeg128-tdm.kicad_pcb')").replace("engineering/block2-ch019-electrode-closed139.zip","engineering/followup-2026-10-16-trunks139/joint-trunks-closed137.zip")
a=s.index('    def test_isolated_via_rejected');z=s.index('    def test_diagnostic_cannot_be_promoted',a)
s=s[:a]+'''    def test_new_via_rejected(self) -> None:
        data = copy.deepcopy(self.data)
        additions = data['additions']
        code = re.search(r'\\(net\\s+(\\d+)\\)', next(iter(additions.values())))[1]
        uid = 'ffffffff-1370-4000-8000-000000000001'
        additions[uid] = ('(via (at 1 1) (size 0.6) (drill 0.3) '
                          '(layers "F.Cu" "B.Cu") (net ' + code + ') (uuid "' + uid + '"))')
        self.reject_without_write(data, 'Unreviewed via')

'''+s[z:]
s=s.replace('class CH021TrunkGuards(S0PreparationGuards):', 'class P25PreparationGuards(S0PreparationGuards):').replace("case = 'n'","case = 'p25'")
a=s.index('class JointTrunkGuards');z=s.index("if __name__",a);s=s[:a]+s[z:]
(r/'test_mux137_followup.py').write_text(s)
