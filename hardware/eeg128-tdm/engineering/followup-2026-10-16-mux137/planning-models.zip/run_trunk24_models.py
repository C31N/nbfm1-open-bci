import subprocess,concurrent.futures,json,os
from pathlib import Path
r=Path('/workspace/scratch/d094b9146fd7/round4');tasks=[('none','none')]+[(n,l) for n in ['CH017_N_MUX','CH018_N_MUX','CH019_P_MUX','CH025_P_MUX','CH025_N_MUX','CH026_N_MUX'] for l in ['In2.Cu','B.Cu']]
def run(pair):
 n,l=pair;res=subprocess.run(['/usr/bin/python3',str(r/'trunk24_topology.py'),n,l],env={**os.environ,'PYTHONPATH':'/workspace/scratch/d094b9146fd7/geom-runtime'},text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(r/('trunk24-'+n+'-'+l+'.log')).write_text(res.stdout);assert res.returncode==0 and (r/('trunk24-'+n+'-'+l+'.json')).exists(),(pair,res.stdout);d=json.loads((r/('trunk24-'+n+'-'+l+'.json')).read_text());print(pair,d['source_target_connected'],flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:results=list(p.map(run,tasks))
(r/'trunk24-topology-models.json').write_text(json.dumps({'accepted':False,'model_only':True,'results':results},indent=2))
