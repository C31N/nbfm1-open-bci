import subprocess,concurrent.futures,json,os
from pathlib import Path
root=Path('/workspace/scratch/d094b9146fd7/round4');tool='/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm/analyze_mux137_escapes.py';tasks=[]
for net,neighbors in [('CH024_P_MUX',['CH019_N_ELECTRODE','CH022_N_ELECTRODE']),('CH024_N_MUX',['CH026_N_ELECTRODE','CH030_N_ELECTRODE','CH031_N_ELECTRODE'])]:
 for n in neighbors:tasks.append((net,[n]))
for outer in ['CH000_N_MUX','CH031_N_MUX']:
 for inner in ['CH016_N_MUX','CH017_N_MUX','CH019_N_MUX','CH021_N_MUX','CH022_N_MUX','CH023_N_MUX','MUX_S0','MUX_S1','BANK1_N_MUX_OUT']:tasks.append(('CH020_N_MUX',[outer,inner]))
def run(task):
 net,names=task;label=net+'--'+'--'.join(names);out=root/(label+'.json');args=['/usr/bin/python3',tool,'--board',str(root/'base137/eeg128-tdm.kicad_pcb'),'--net',net,'--output',str(out)]
 for n in names:args+=['--remove-net',n]
 r=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONPATH':'/workspace/scratch/d094b9146fd7/geom-runtime'});(root/(label+'.log')).write_text(r.stdout)
 assert r.returncode==0 and out.exists(),(label,r.returncode,r.stdout)
 d=json.loads(out.read_text())['results'][net];result={'net':net,'removed_nets':names,'source':d['source']['window'],'target':d['target']['window'],'accepted':False};print(net,names,'S',result['source']['legal_via_area_mm2'],'T',result['target']['legal_via_area_mm2'],flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,tasks))
(root/'additional-removal-models.json').write_text(json.dumps({'model_only':True,'accepted':False,'routing_completed':False,'fabrication_release':False,'results':results},indent=2))
