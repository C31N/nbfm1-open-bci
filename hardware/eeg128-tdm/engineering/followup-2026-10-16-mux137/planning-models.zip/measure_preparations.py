import sys,json,math
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from analyze_139_escape_blockers import windows,protected_power
from route_targeted_closure import xy,routing_domain
from shapely.geometry import box,LineString
root=Path('/workspace/scratch/d094b9146fd7/round4');case=sys.argv[1];base=pcbnew.LoadBoard(str(root/'base137/eeg128-tdm.kicad_pcb'));candidate=pcbnew.LoadBoard(str(root/('s0-native' if case=='s0' else 'prepare25-0')/'eeg128-tdm.kicad_pcb'));targetnet,point,changed=('CH020_N_MUX',(38.595,58.15),'MUX_S0') if case=='s0' else ('CH024_P_MUX',(34.785,35.85),'CH025_P_MUX');result={};region=box(12,.5,59,69)
for label,b in [('before',base),('after',candidate)]:
 net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()==targetnet);_,w=windows(b,net,point,region,protected_power(b));tracks=[t for t in b.GetTracks() if t.GetNetname()==changed];result[label]={'window':w,'length_mm':sum(pcbnew.ToMM(t.GetLength()) for t in tracks if not isinstance(t,pcbnew.PCB_VIA)),'vias':sum(isinstance(t,pcbnew.PCB_VIA) for t in tracks)}
result.update({'case':case,'analyzed_net':targetnet,'changed_net':changed,'accepted':False,'routing_completed':False,'fabrication_release':False,'delta_length_mm':result['after']['length_mm']-result['before']['length_mm']})
repo=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm/engineering/followup-2026-10-16-mux137');recipe=json.loads((repo/f'{case}-recipe.json').read_text());domain=routing_domain(candidate,.075);newtracks=[t for t in candidate.GetTracks() if t.m_Uuid.AsString() in recipe['additions']];assert all(not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()==pcbnew.F_Cu for t in newtracks);assert all(domain.covers(LineString([xy(t.GetStart()),xy(t.GetEnd())])) for t in newtracks);result.update({'new_vias':0,'new_In2_tracks':0,'all_new_tracks_F_Cu':True,'new_copper_inside_025_edge_domain':True})
(repo/f'{case}-window-metrics.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
