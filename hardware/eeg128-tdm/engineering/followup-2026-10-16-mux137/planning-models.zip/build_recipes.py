from pathlib import Path
import sys,re,json,hashlib
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
from merge_native_closure import copper
from replay_block2_source_window import reproducible_zip,MEMBERS
root=Path('/workspace/scratch/d094b9146fd7/round4');repo=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm');out=repo/'engineering/followup-2026-10-16-mux137';out.mkdir(exist_ok=True);base=root/'base137';name='eeg128-tdm.kicad_pcb';oldtext=(base/name).read_text();old=copper(oldtext);norm=lambda s:re.sub(r'\s+','',s);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for case,sub in [('s0','s0-native'),('p25','prepare25-0'),('joint','joint-native')]:
 candidate=root/sub;new=copper((candidate/name).read_text());changes={k:{'before':v,'after':new.get(k,'')} for k,v in old.items() if norm(new.get(k,''))!=norm(v)};adds={k:v for k,v in new.items() if k not in old};text=oldtext
 for c in changes.values():text=text.replace(c['before'],c['after'],1)
 text=text[:text.rfind(')')]+'\n'+'\n'.join(adds.values())+'\n)\n';reproducible_zip(candidate,out/f'{case}-unadopted137.zip')
 r={'scope':'BLOCK2_MUX137_PREPARATION_'+case.upper(),'baseline_archive_sha256':'50e62977c202838640dfb00a6580f1e010c71503711e8a8fb85c7244a9d4a6f3','baseline_member_sha256':{n:digest(base/n) for n in MEMBERS},'changes':changes,'additions':adds,'expected_applied_sha256':hashlib.sha256(text.encode()).hexdigest(),'expected_pcb_sha256':digest(candidate/name),'expected_archive_sha256':digest(out/f'{case}-unadopted137.zip'),'routing_completed':False,'fabrication_release':False,'accepted':False};p=out/f'{case}-recipe.json';p.write_text(json.dumps(r,indent=2)+'\n');print(case,'recipe',digest(p),'PCB',r['expected_pcb_sha256'],'ZIP',r['expected_archive_sha256'],'changes',len(changes),len(adds))
