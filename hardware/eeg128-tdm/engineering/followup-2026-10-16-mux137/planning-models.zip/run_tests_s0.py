import subprocess,os,re,json
from pathlib import Path
root=Path('/workspace/scratch/d094b9146fd7/round4/tests-s0');cwd='/workspace/scratch/d094b9146fd7/repo';env={**os.environ,'PYTHONPATH':'/workspace/scratch/d094b9146fd7/geom-runtime'};results=[]
for f in sorted(Path(cwd,'hardware/eeg128-tdm').glob('test_*.py')):
 r=subprocess.run(['/usr/bin/python3','-m','unittest','discover','-s','hardware/eeg128-tdm','-p',f.name,'-v'],cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
 (root/('isolated-'+f.name+'.log')).write_text(r.stdout)
 match=re.search(r'Ran (\d+) tests?',r.stdout);ok=bool(r.returncode==0 and match and '\nOK\n' in r.stdout)
 results.append({'file':f.name,'returncode':r.returncode,'tests':int(match[1]) if match else None,'passed':ok});print(results[-1],flush=True)
 (root/'isolated-tests-summary.json').write_text(json.dumps({'results':results,'all_passed':all(x['passed'] for x in results),'tests':sum(x['tests'] or 0 for x in results)},indent=2))
 if not ok:raise SystemExit('Missing complete unittest success summary')
