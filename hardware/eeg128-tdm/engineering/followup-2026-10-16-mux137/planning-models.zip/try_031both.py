import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh import mesh_route,add_mesh_path
from analyze_139_escape_blockers import windows,protected_power
from route_targeted_closure import xy,native_fresh,metrics
from shapely.geometry import box,Polygon
root=Path('/workspace/scratch/d094b9146fd7/round4');name=sys.argv[1];mode=sys.argv[2];base=root/'base137/eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(12,.5,59,69);removed=[]
for t in list(b.GetTracks()):
 if t.GetNetname()=='CH031_N_MUX' and t.m_Uuid.AsString()!='7637c97e-91bd-4d5f-8647-e847bf82bd59':removed.append(t);b.Remove(t)
net=b.FindNet(name).GetNetCode();pads=[(f.GetReference(),p) for f in b.GetFootprints() for p in f.Pads() if p.GetNetCode()==net];start=xy(next(p for ref,p in pads if ref.startswith('R') and p.GetNumber()=='1').GetPosition());goal=xy(next(p for ref,p in pads if ref.startswith('U')).GetPosition());_,w=windows(b,net,goal,region,power);print('target window',w,flush=True);paths=[]
for n,s,g,ls,allow in [(name,start,goal,(pcbnew.F_Cu,pcbnew.B_Cu) if mode=='fb' else (pcbnew.F_Cu,pcbnew.In2_Cu),True),('CH031_N_MUX',(48.75,31.2),(43.675,48.85),(pcbnew.F_Cu,pcbnew.In2_Cu),True)]:
 code=b.FindNet(n).GetNetCode();extra=[power.buffer(.505) if l==pcbnew.In2_Cu else Polygon() for l in ls];path=mesh_route(b,s,g,code,ls,power,region,extra_obstacles=extra);paths.append({'net':n,'layers':[b.GetLayerName(l) for l in ls],'path':path});print(n,mode,path is not None,flush=True)
 if path is None:break
 add_mesh_path(b,path,code,ls)
out=root/(name+'-031both-'+mode);out.mkdir(exist_ok=True);r={'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'target_window':w,'accepted':False,'routing_completed':False,'fabrication_release':False,'complete':len(paths)==2 and all(p['path'] for p in paths)};(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 p=out/base.name;pcbnew.SaveBoard(str(p),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),p.with_suffix(ext))
 print('NATIVE',metrics(native_fresh(p,out/'drc.json')),flush=True)
