import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh import mesh_route,add_mesh_path
from analyze_139_escape_blockers import protected_power
from shapely.geometry import box,Polygon
from route_targeted_closure import xy,native_fresh,metrics
root=Path('/workspace/scratch/d094b9146fd7/round4');name=sys.argv[1];mode=sys.argv[2] if len(sys.argv)>2 else 'fb';base=root/'base137/eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));net=b.FindNet(name).GetNetCode();pads=[(f.GetReference(),p) for f in b.GetFootprints() for p in f.Pads() if p.GetNetCode()==net];start=xy(next(p for ref,p in pads if ref.startswith('R') and p.GetNumber()=='1').GetPosition());goal=xy(next(p for ref,p in pads if ref.startswith('U')).GetPosition());power=protected_power(b);layers=(pcbnew.F_Cu,pcbnew.B_Cu) if mode=='fb' else (pcbnew.F_Cu,pcbnew.In2_Cu);extra=[power.buffer(.505) if l==pcbnew.In2_Cu else Polygon() for l in layers];path=mesh_route(b,start,goal,net,layers,power,box(12,.5,59,69),extra_obstacles=extra);print(name,mode,'path',path is not None,flush=True);out=root/(name+'-'+mode);out.mkdir(exist_ok=True);(out/'plan.json').write_text(json.dumps({'net':name,'start':start,'goal':goal,'layers':[b.GetLayerName(l) for l in layers],'path':path,'complete':path is not None,'accepted':False,'routing_completed':False,'fabrication_release':False,'power_exclusion_mm':.505},indent=2))
if path:
 add_mesh_path(b,path,net,layers);p=out/base.name;pcbnew.SaveBoard(str(p),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),p.with_suffix(ext))
 print('NATIVE',metrics(native_fresh(p,out/'drc.json')),flush=True)
