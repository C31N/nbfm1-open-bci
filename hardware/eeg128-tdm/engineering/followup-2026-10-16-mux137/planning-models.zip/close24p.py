import sys,json,shutil,math
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh_505 import mesh_route,add_mesh_path
from analyze_139_escape_blockers import protected_power
from route_targeted_closure import xy,make_via,obstacles,native_fresh,metrics
from shapely.geometry import box,Point
root=Path('/workspace/scratch/d094b9146fd7/round4');case=int(sys.argv[1]);base=root/'prepare25-0/eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(12,.5,59,69);removed=[t for t in b.GetTracks() if t.GetNetname()=='CH022_N_ELECTRODE']
for t in removed:b.Remove(t)
main='CH024_P_MUX';net=b.FindNet(main).GetNetCode();sv=[(44.1186,16.9),(44.02605,9.208769),(43.962046,19.571068)][case//2];tv=(32.825,33.635907);paths=[];actual={}
for key,s,g in [('source',(43.25,13),sv),('target',(34.785,35.85),tv)]:
 ls=(pcbnew.F_Cu,pcbnew.B_Cu);_,v=obstacles(b,net,.15,.15,region,.6,ls)
 if v.covers(Point(g)) or power.buffer(.505).covers(Point(g)):print(key,'VIA BLOCKED',flush=True);paths.append({'net':main,'path':None});break
 p=mesh_route(b,s,g,net,ls,power,region,allow_vias=False);print(key,p is not None,flush=True);paths.append({'net':main,'layers':[b.GetLayerName(l) for l in ls],'path':p})
 if p is None:break
 add_mesh_path(b,p,net,ls);make_via(b,g,net,.6);actual[key]=next(xy(t.GetPosition()) for t in b.GetTracks() if isinstance(t,pcbnew.PCB_VIA) and t.GetNetCode()==net and math.dist(xy(t.GetPosition()),g)<.000002)
if len(actual)==2:
 trunks=[(main,actual['source'],actual['target'],(pcbnew.B_Cu,pcbnew.In2_Cu,pcbnew.F_Cu),0,0),('CH022_N_ELECTRODE',(36.15,15.6),(43.75,7.6),(pcbnew.F_Cu,pcbnew.B_Cu,pcbnew.In2_Cu),0,0)]
 if case%2:trunks.reverse()
 for n,s,g,ls,sl,gl in trunks:
  code=b.FindNet(n).GetNetCode();p=mesh_route(b,s,g,code,ls,power,region,sl,gl);print(n,p is not None,flush=True);paths.append({'net':n,'layers':[b.GetLayerName(l) for l in ls],'path':p})
  if p is None:break
  add_mesh_path(b,p,code,ls)
out=root/f'close24p-{case}';out.mkdir(exist_ok=True);r={'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'complete':len(paths)==4 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 p=out/base.name;pcbnew.SaveBoard(str(p),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),p.with_suffix(ext))
 print('NATIVE',metrics(native_fresh(p,out/'drc.json')),flush=True)
