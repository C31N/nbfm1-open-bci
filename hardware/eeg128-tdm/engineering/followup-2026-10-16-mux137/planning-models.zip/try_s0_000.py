import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh_505 import mesh_route,add_mesh_path
from analyze_139_escape_blockers import protected_power
from route_targeted_closure import xy,native_fresh,metrics
from shapely.geometry import box
root=Path('/workspace/scratch/d094b9146fd7/round4');case=int(sys.argv[1]);base=root/'base137/eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(10,.5,60,69);removed=[]
for t in list(b.GetTracks()):
 remove=t.GetNetname()=='CH000_N_MUX' and t.m_Uuid.AsString()!='eb79c185-8b9f-433a-9abb-9007b796947f'
 if t.GetNetname()=='MUX_S0' and not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()==pcbnew.F_Cu:
  a,c=xy(t.GetStart()),xy(t.GetEnd())
  if min(a[0],c[0])>=21.9449 and max(a[0],c[0])<=43.987 and min(a[1],c[1])>=56.8756 and max(a[1],c[1])<=59.401 and t.m_Uuid.AsString()!='b017f7cd-04c7-4c6d-8256-06aa110ff856':remove=True
 if remove:removed.append(t);b.Remove(t)
requests=[('CH020_P_MUX',(32.75,20.8),(38.595,45.15),(pcbnew.F_Cu,pcbnew.B_Cu,pcbnew.In2_Cu),True),('CH000_N_MUX',(15.25,31.2),(20.675,58.15),(pcbnew.F_Cu,pcbnew.B_Cu,pcbnew.In2_Cu),True),('MUX_S0',(21.945,58.15),(33.,61.),(pcbnew.F_Cu,pcbnew.B_Cu),False),('MUX_S0',(33.,61.),(44.945,58.15),(pcbnew.F_Cu,pcbnew.B_Cu),False)]
if case:requests=requests[2:]+requests[:2]
paths=[]
for name,start,goal,layers,allow in requests:
 net=b.FindNet(name).GetNetCode();p=mesh_route(b,start,goal,net,layers,power,region,allow_vias=allow);print(name,start,goal,p is not None,flush=True);paths.append({'net':name,'layers':[b.GetLayerName(l) for l in layers],'path':p})
 if p is None:break
 add_mesh_path(b,p,net,layers)
out=root/f's0-000-{case}';out.mkdir(exist_ok=True);r={'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'complete':len(paths)==4 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 p=out/base.name;pcbnew.SaveBoard(str(p),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),p.with_suffix(ext))
 print('NATIVE',metrics(native_fresh(p,out/'drc.json')),flush=True)
