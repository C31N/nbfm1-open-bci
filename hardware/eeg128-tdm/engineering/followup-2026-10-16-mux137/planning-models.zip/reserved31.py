import sys,json,shutil,math
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh_505 import mesh_route,add_mesh_path
from analyze_139_escape_blockers import protected_power
from route_targeted_closure import xy,make_via,obstacles,native_fresh,metrics
from shapely.geometry import box,Point
root=Path('/workspace/scratch/d094b9146fd7/round4');case=int(sys.argv[1]);base=root/'base137/eeg128-tdm.kicad_pcb';b=pcbnew.LoadBoard(str(base));power=protected_power(b);region=box(12,.5,59,69);removed=[]
for t in list(b.GetTracks()):
 if t.GetNetname()=='CH031_N_MUX' and t.m_Uuid.AsString()!='7637c97e-91bd-4d5f-8647-e847bf82bd59':removed.append(t);b.Remove(t)
sv31=(47.320486,29.792634);tv31=(48.125859,33.878633);sv29=(49.440043,29.73001);tv29=(46.323609,27.465318);paths=[];actual={}
heads=[('CH031_N_MUX',(48.75,31.2),sv31,'s31'),('CH031_N_MUX',(43.675,48.85),tv31,'t31'),('CH029_N_MUX',(41.135,48.85),tv29,'t29'),('CH029_N_MUX',(48.75,26),sv29,'s29')]
for n,start,goal,key in heads:
 net=b.FindNet(n).GetNetCode();ls=(pcbnew.F_Cu,pcbnew.B_Cu);_,viaobs=obstacles(b,net,.15,.15,region,.6,ls)
 if viaobs.covers(Point(goal)) or power.buffer(.505).covers(Point(goal)):print(key,'via blocked',flush=True);paths.append({'net':n,'path':None});break
 p=mesh_route(b,start,goal,net,ls,power,region,allow_vias=False);print(key,p is not None,flush=True);paths.append({'net':n,'layers':[b.GetLayerName(l) for l in ls],'path':p})
 if p is None:break
 add_mesh_path(b,p,net,ls);make_via(b,goal,net,.6);actual[key]=next(xy(t.GetPosition()) for t in b.GetTracks() if isinstance(t,pcbnew.PCB_VIA) and t.GetNetCode()==net and math.dist(xy(t.GetPosition()),goal)<.000002)
if len(actual)==4:
 ts=[('CH031_N_MUX','s31','t31'),('CH029_N_MUX','s29','t29')]
 if case%2:ts.reverse()
 for n,start,goal in ts:
  net=b.FindNet(n).GetNetCode();ls=(pcbnew.B_Cu,pcbnew.In2_Cu) if case<2 else (pcbnew.B_Cu,pcbnew.In2_Cu,pcbnew.F_Cu);p=mesh_route(b,actual[start],actual[goal],net,ls,power,region);print('trunk',n,p is not None,flush=True);paths.append({'net':n,'layers':[b.GetLayerName(l) for l in ls],'path':p})
  if p is None:break
  add_mesh_path(b,p,net,ls)
out=root/f'reserved31-{case}';out.mkdir(exist_ok=True);r={'removed':[t.m_Uuid.AsString() for t in removed],'paths':paths,'complete':len(paths)==6 and all(p['path'] for p in paths),'accepted':False,'routing_completed':False,'fabrication_release':False};(out/'plan.json').write_text(json.dumps(r,indent=2))
if r['complete']:
 p=out/base.name;pcbnew.SaveBoard(str(p),b)
 for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),p.with_suffix(ext))
 print('NATIVE',metrics(native_fresh(p,out/'drc.json')),flush=True)
