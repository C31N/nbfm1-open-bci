import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy
from analyze_139_escape_blockers import windows,protected_power
from shapely.geometry import box,Point,LineString
root=Path('/workspace/scratch/d094b9146fd7/round4');case=sys.argv[1];b=pcbnew.LoadBoard(str(root/'base137/eeg128-tdm.kicad_pcb'));power=protected_power(b);region=box(12,.5,59,69);names=json.loads((root/'escape-inventory.json').read_text())['results'];output={'accepted':False,'routing_completed':False,'fabrication_release':False,'model_only':True,'results':{}}
for name,info in names.items():
 if case!='all' and name not in case.split(','):continue
 net=b.FindNet(name).GetNetCode();terminals={}
 for label,pad in [('source',next(p for p in info['pads'] if p['ref'].startswith('R') and p['pad']=='1')),('target',next(p for p in info['pads'] if p['ref'].startswith('U')))]:
  pt=tuple(pad['point']);comp,w=windows(b,net,pt,region,power);neighbors={}
  for t in b.GetTracks():
   if t.GetNetCode()==net:continue
   if not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()!=pcbnew.F_Cu:continue
   shape=Point(xy(t.GetPosition())) if isinstance(t,pcbnew.PCB_VIA) else LineString([xy(t.GetStart()),xy(t.GetEnd())]);dist=shape.distance(comp)-pcbnew.ToMM(t.GetWidth())/2
   if dist<.4:neighbors.setdefault(t.GetNetname(),[]).append({'uuid':t.m_Uuid.AsString(),'via':isinstance(t,pcbnew.PCB_VIA),'layer':b.GetLayerName(t.GetLayer()),'start':xy(t.GetStart()),'end':xy(t.GetEnd()),'distance_mm':dist})
  trials=[];print(name,label,'baseline',w['bounds'],w['legal_via_area_mm2'],'neighbors',list(neighbors),flush=True)
  for neighbor in sorted(neighbors):
   if not ('MUX' in neighbor):continue
   removed=[t for t in b.GetTracks() if t.GetNetname()==neighbor]
   for t in removed:b.Remove(t)
   try:_,after=windows(b,net,pt,region,power)
   finally:
    for t in removed:b.Add(t)
   trials.append({'removed_net':neighbor,'removed_uuids':[t.m_Uuid.AsString() for t in removed],**after,'accepted':False,'neighbor_restored':False});print(name,label,neighbor,after['legal_via_area_mm2'],flush=True)
  terminals[label]={'pad':pad['ref']+'.'+pad['pad'],'point':pt,'baseline':w,'neighbors':neighbors,'whole_net_removal_models':trials}
  output['results'][name]=terminals;(root/f'blockers-{case}.json').write_text(json.dumps(output,indent=2))
