import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh_505 import add_mesh_path
from route_targeted_closure import native_fresh,metrics
root=Path('/workspace/scratch/d094b9146fd7/round4');base=root/'base137/eeg128-tdm.kicad_pcb';d=json.loads((root/'s0-000-1/plan.json').read_text());b=pcbnew.LoadBoard(str(base));removed=[t for t in b.GetTracks() if t.m_Uuid.AsString() in d['removed'] and t.GetNetname()=='MUX_S0'];print('S0 removed',len(removed),flush=True)
for t in removed:b.Remove(t)
for path in d['paths'][:2]:
 assert path['net']=='MUX_S0' and path['path'];add_mesh_path(b,path['path'],b.FindNet('MUX_S0').GetNetCode(),(pcbnew.F_Cu,pcbnew.B_Cu))
out=root/'s0-native';out.mkdir(exist_ok=True);p=out/base.name;pcbnew.SaveBoard(str(p),b)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copy2(base.with_suffix(ext),p.with_suffix(ext))
print('NATIVE',metrics(native_fresh(p,out/'drc.json')),flush=True)
