import sys,json,shutil
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
from replay_mux137_followup import apply,recipe
from route_targeted_closure import native_fresh,metrics
from replay_block2_source_window import MEMBERS
root=Path('/workspace/scratch/d094b9146fd7/round4');out=root/'joint-native';out.mkdir(exist_ok=False);base=root/'base137'
for n in MEMBERS:shutil.copy2(base/n,out/n)
p=out/'eeg128-tdm.kicad_pcb';text=p.read_text()
for case in ['s0','p25']:
 data=recipe(case)
 for c in data['changes'].values():assert text.count(c['before'])==1;text=text.replace(c['before'],c['after'],1)
 text=text[:text.rfind(')')]+'\n'+'\n'.join(data['additions'].values())+'\n)\n'
p.write_text(text);print(metrics(native_fresh(p,out/'drc.json')),flush=True)
