import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from analyze_139_escape_blockers import windows,protected_power
from route_targeted_closure import xy
from shapely.geometry import box,Point
root=Path('/workspace/scratch/d094b9146fd7/round4');b=pcbnew.LoadBoard(str(root/'base137/eeg128-tdm.kicad_pcb'));power=protected_power(b);removed=[]
for t in list(b.GetTracks()):
 if t.m_Uuid.AsString()=='dea57ba5-1b4a-41a4-881f-52f3c6a63d6a':removed.append(t);b.Remove(t)
for name,pt in [('CH029_N_MUX',(41.135,48.85)),('CH031_N_MUX',(48.25,36.6436)),('CH031_N_MUX',(48.75,31.2))]:
 _,w=windows(b,b.FindNet(name).GetNetCode(),pt,box(12,.5,59,69),power);print(name,pt,'powerdistance',Point(pt).distance(power),w,flush=True)
