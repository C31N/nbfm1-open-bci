import subprocess,os,concurrent.futures,json
from pathlib import Path
r=Path('/workspace/scratch/d094b9146fd7/round4');tool='/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm/analyze_mux137_escapes.py';tasks=[('CH031_N_MUX',['CH020_P_MUX','CH028_N_MUX','CH029_N_MUX','CH030_N_MUX']),('CH000_N_MUX',['CH020_P_MUX','CH028_N_MUX','CH029_N_MUX','CH030_N_MUX']),('CH025_P_MUX',['CH020_N_MUX']),('CH026_P_MUX',['CH020_N_MUX']),('CH025_N_MUX',['CH024_N_MUX']),('CH027_N_MUX',['CH024_N_MUX']),('MUX_S3',['CH024_N_MUX'])]
def run(task):
 neighbor,nets=task;out=r/('verified-removal-'+neighbor+'.json');args=['/usr/bin/python3',tool,'--board',str(r/'base137/eeg128-tdm.kicad_pcb'),'--remove-net',neighbor,'--output',str(out)]
 for n in nets:args+=['--net',n]
 p=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONPATH':'/workspace/scratch/d094b9146fd7/geom-runtime'});assert p.returncode==0 and out.exists(),(neighbor,p.stdout);d=json.loads(out.read_text());print(neighbor,[(n,d['results'][n]['source']['window']['legal_via_area_mm2'],d['results'][n]['target']['window']['legal_via_area_mm2']) for n in nets],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:list(p.map(run,tasks))
