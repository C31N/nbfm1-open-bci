import sys,hashlib,zipfile,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy,connected_anchors
from analyze_139_escape_blockers import windows,protected_power
from shapely.geometry import box
root=Path('/workspace/scratch/d094b9146fd7/round4');base=root/'base137';base.mkdir(exist_ok=True);archive=Path('/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm/engineering/followup-2026-10-16-trunks139/joint-trunks-closed137.zip');assert hashlib.sha256(archive.read_bytes()).hexdigest()=='50e62977c202838640dfb00a6580f1e010c71503711e8a8fb85c7244a9d4a6f3'
with zipfile.ZipFile(archive) as z:
 for n in z.namelist():(base/n).write_bytes(z.read(n))
b=pcbnew.LoadBoard(str(base/'eeg128-tdm.kicad_pcb'));power=protected_power(b);results={}
for name in ['CH020_N_MUX','CH020_P_MUX','CH024_N_MUX','CH024_P_MUX','CH028_N_MUX','CH029_N_MUX','CH030_N_MUX']:
 net=b.FindNet(name).GetNetCode();pads=[]
 for f in b.GetFootprints():
  for p in f.Pads():
   if p.GetNetCode()!=net:continue
   pt=xy(p.GetPosition());anchors=connected_anchors(b,p);_,w=windows(b,net,pt,box(12,.5,59,69),power);pads.append({'ref':f.GetReference(),'pad':p.GetNumber(),'point':pt,'anchors':anchors,'window':w})
 tracks=[{'uuid':t.m_Uuid.AsString(),'layer':b.GetLayerName(t.GetLayer()),'via':isinstance(t,pcbnew.PCB_VIA),'start':xy(t.GetStart()),'end':xy(t.GetEnd())} for t in b.GetTracks() if t.GetNetCode()==net]
 results[name]={'net_code':net,'pads':pads,'tracks':tracks};print(name,[(p['ref'],p['pad'],p['point'],p['window']['component_area_mm2'],p['window']['legal_via_area_mm2']) for p in pads],flush=True)
(root/'escape-inventory.json').write_text(json.dumps({'accepted':False,'routing_completed':False,'fabrication_release':False,'results':results},indent=2))
