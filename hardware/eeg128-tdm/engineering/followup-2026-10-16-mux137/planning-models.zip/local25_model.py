import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from route_targeted_closure import xy
from analyze_139_escape_blockers import windows,protected_power
from shapely.geometry import box
root=Path('/workspace/scratch/d094b9146fd7/round4');b=pcbnew.LoadBoard(str(root/'base137/eeg128-tdm.kicad_pcb'));removed=[]
for t in list(b.GetTracks()):
 if t.GetNetname()=='CH025_P_MUX' and not isinstance(t,pcbnew.PCB_VIA) and t.GetLayer()==pcbnew.F_Cu and min(xy(t.GetStart())[1],xy(t.GetEnd())[1])>33:removed.append(t);b.Remove(t)
_,w=windows(b,b.FindNet('CH024_P_MUX').GetNetCode(),(34.785,35.85),box(12,.5,59,69),protected_power(b));print('REMOVED',len(removed),'WINDOW',w,flush=True);(root/'local25-window.json').write_text(json.dumps({'removed':[t.m_Uuid.AsString() for t in removed],'window':w,'accepted':False},indent=2))
