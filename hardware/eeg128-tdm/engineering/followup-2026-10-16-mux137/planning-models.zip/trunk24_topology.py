import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/d094b9146fd7/repo/hardware/eeg128-tdm')
import pcbnew
from escape_mesh_505 import add_mesh_path
from escape_mesh import polygons
from analyze_139_escape_blockers import protected_power
from route_targeted_closure import obstacles,xy,make_via
from shapely.geometry import Point,box
from shapely.ops import unary_union
from shapely.strtree import STRtree
root=Path('/workspace/scratch/d094b9146fd7/round4');base=root/'prepare25-0/eeg128-tdm.kicad_pcb';assert hashlib.sha256(base.read_bytes()).hexdigest()=='1288c3eceb85f7660424c66a51613ed2231986852bd2f616eb042ef44ca36608';b=pcbnew.LoadBoard(str(base));name=sys.argv[1] if len(sys.argv)>1 else 'none';layer=sys.argv[2] if len(sys.argv)>2 else 'none';ls=(pcbnew.F_Cu,pcbnew.B_Cu,pcbnew.In2_Cu);removed=[t for t in b.GetTracks() if t.GetNetname()=='CH022_N_ELECTRODE' or (t.GetNetname()==name and b.GetLayerName(t.GetLayer())==layer and not isinstance(t,pcbnew.PCB_VIA))]
for t in removed:b.Remove(t)
net=next(p.GetNetCode() for f in b.GetFootprints() for p in f.Pads() if p.GetNetname()=='CH024_P_MUX')
heads=json.loads((root/'close24p-0/plan.json').read_text())['paths'][:2]
for h in heads:add_mesh_path(b,h['path'],net,(pcbnew.F_Cu,pcbnew.B_Cu));make_via(b,h['path'][-1][1:],net,.6)
power=protected_power(b);region=box(12,.5,59,69);fb,via=obstacles(b,net,.15,.15,region,.6,ls[:2]);fi,_=obstacles(b,net,.15,.15,region,.6,(ls[0],ls[2]));blocked=[fb[0],fb[1],unary_union([fi[1],power.buffer(.505)])];free=[polygons(region.difference(s).buffer(-.000005)) for s in blocked];trees=[STRtree(p) for p in free];adj={(l,i):set() for l in range(3) for i in range(len(free[l]))}
def members(pt):
 return [(l,int(i)) for l in range(3) for i in trees[l].query(pt) if free[l][int(i)].covers(pt)]
patches=polygons(region.difference(unary_union([via,power.buffer(.505)])).buffer(-.000005));points=[p.representative_point() for p in patches if p.area>1e-10]+[Point(xy(t.GetPosition())) for t in b.GetTracks() if isinstance(t,pcbnew.PCB_VIA) and t.GetNetCode()==net]
for p in points:
 ids=members(p)
 for a in ids:adj[a].update(set(ids)-{a})
source=[n for n in members(Point(43.25,13)) if n[0]==0];target=[n for n in members(Point(34.785,35.85)) if n[0]==0];q=list(source);seen=set()
while q:
 n=q.pop()
 if n in seen:continue
 seen.add(n);q.extend(adj[n]-seen)
r={'model_only':True,'accepted':False,'routing_completed':False,'fabrication_release':False,'removed_mux_neighbor':name,'removed_layer':layer,'E22_restored':False,'removed_mux_restored':False,'region_mm':list(region.bounds),'power_exclusion_mm':.505,'edge_clearance_mm':.25,'component_counts':[len(p) for p in free],'source_target_connected':bool(set(target)&seen),'reachable_components':len(seen),'legal_via_patches':len(patches)}
out=root/('trunk24-'+name+'-'+layer+'.json');out.write_text(json.dumps(r,indent=2));print(r)
